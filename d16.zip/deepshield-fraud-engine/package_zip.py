import os
import zipfile
import shutil


def package_project():
    source_dir = os.path.dirname(os.path.abspath(__file__))
    zip_name = "deepshield_fraud_engine.zip"
    zip_path = os.path.join(source_dir, zip_name)

    exclude_dirs = {".git", "__pycache__", ".pytest_cache", ".vscode", ".idea", "venv", "env", ".system_generated"}
    exclude_extensions = {".pyc", ".pyo", ".pyd"}

    files_to_zip = []
    for root, dirs, files in os.walk(source_dir):
        dirs[:] = [d for d in dirs if d not in exclude_dirs]
        for file in files:
            if file == zip_name or any(file.endswith(ext) for ext in exclude_extensions):
                continue
            full_path = os.path.join(root, file)
            rel_path = os.path.relpath(full_path, source_dir)
            files_to_zip.append((full_path, rel_path))

    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for full_path, rel_path in sorted(files_to_zip):
            zf.write(full_path, os.path.join("deepshield-fraud-engine", rel_path))

    destinations = [
        r"C:\Users\HP\Downloads\deepshield_fraud_engine.zip",
        r"C:\Users\HP\deepshield_fraud_engine.zip",
        r"C:\Users\HP\.gemini\antigravity\scratch\deepshield_fraud_engine.zip",
        r"C:\Users\HP\.gemini\antigravity\brain\e9c1a96c-7cd1-4fe0-a4a4-4f7404879953\deepshield_fraud_engine.zip"
    ]

    for dst in destinations:
        try:
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            shutil.copy2(zip_path, dst)
            print(f"[OK] Synced: {dst}")
        except Exception as e:
            print(f"[ERROR] Sync failed for {dst}: {e}")

    size_mb = os.path.getsize(zip_path) / (1024 * 1024)
    print("=" * 70)
    print(f"[OK] Created fresh ZIP archive: {zip_path}")
    print(f"[METRICS] Packaged {len(files_to_zip)} files ({size_mb:.2f} MB)")
    print("=" * 70)


if __name__ == "__main__":
    package_project()
