"""
DeepShield End-to-End System & Web View Verification Script
Verifies:
1. Health check & system status
2. Frontend static assets & HTML accessibility
3. All 4 Attack scenario simulations
4. Real media file uploads (audio & video detection)
5. Custom INR wire transfer authorization gatekeeper & audit logging
6. SHA-256 Ledger cryptographic verification
7. Streaming frame telemetry endpoint
"""

import os
import sys
import io
import json

root_dir = os.path.dirname(os.path.abspath(__file__))
if root_dir not in sys.path:
    sys.path.insert(0, root_dir)

from fastapi.testclient import TestClient
from backend.app import app

client = TestClient(app)


def verify_system_and_web():
    print("=" * 80)
    print("[AUDIT] STARTING COMPREHENSIVE END-TO-END DEEPSHIELD VERIFICATION...")
    print("=" * 80)

    # 1. Health check
    res = client.get("/api/v1/health")
    assert res.status_code == 200 and res.json()["status"] == "HEALTHY"
    print("  [OK] 1. Backend Health Check: HEALTHY")

    # 2. Frontend HTML & static files
    res_index = client.get("/")
    assert res_index.status_code == 200 and "DEEPSHIELD" in res_index.text
    print("  [OK] 2. Frontend HTML View (index.html): 200 OK")

    res_css = client.get("/static/css/styles.css")
    assert res_css.status_code == 200 and "cyber-theme" in res_css.text
    print("  [OK] 3. Frontend Stylesheet (styles.css): 200 OK")

    for js_file in ["visualizer.js", "banking_demo.js", "app.js"]:
        res_js = client.get(f"/static/js/{js_file}")
        assert res_js.status_code == 200 and len(res_js.text) > 100
        print(f"  [OK] 4. Frontend Script ({js_file}): 200 OK")

    # 3. Test all 4 attack scenario simulations
    scenarios = ["voice_clone_wire_fraud", "deepfake_video_kyc", "dubbed_lip_desync", "authentic_ceo"]
    for sc in scenarios:
        res_sc = client.post("/api/v1/banking/simulate-scenario", json={
            "scenario": sc,
            "account_from": "HDFC-CORP-TREASURY-098",
            "account_to": "ICICI-OFFSHORE-44102",
            "transfer_amount_usd": 2500000.0
        })
        assert res_sc.status_code == 200
        data = res_sc.json()
        assert "risk_report" in data and "authorization_decision" in data
        score = data["risk_report"]["overall_risk_score"]
        decision = data["authorization_decision"]["decision"]
        print(f"  [OK] 5. Simulation Scenario '{sc}': Score {score}/100 -> Decision: {decision}")

    # 4. Test real media upload detection
    sample_wav = os.path.join(root_dir, "samples", "ceo_voice_clone_urgent_wire.wav")
    if os.path.exists(sample_wav):
        with open(sample_wav, "rb") as f:
            wav_bytes = f.read()
        res_audio = client.post("/api/v1/detect/audio", files={"file": ("ceo_clone.wav", wav_bytes, "audio/wav")})
        assert res_audio.status_code == 200
        audio_data = res_audio.json()
        assert audio_data["is_synthetic"] is True
        print(f"  [OK] 6. Real Audio Detection API: Flagged Vocoder Cutoff (Risk: {audio_data['risk_score']}/100)")

    # 5. Test stream-frame telemetry API
    import cv2, numpy as np, base64
    dummy_frame = np.zeros((100, 100, 3), dtype=np.uint8)
    _, buf = cv2.imencode('.jpg', dummy_frame)
    b64_frame = "data:image/jpeg;base64," + base64.b64encode(buf).decode('utf-8')

    res_stream = client.post("/api/v1/detect/stream-frame", json={"frame_base64": b64_frame})
    assert res_stream.status_code == 200
    stream_data = res_stream.json()
    assert "current_risk_score" in stream_data
    print(f"  [OK] 7. Live Stream Frame Telemetry API: 200 OK (EAR: {stream_data['ear']})")

    # 6. Test Custom INR Wire Transfer Authorization
    res_transfer = client.post("/api/v1/banking/authorize-transfer", json={
        "account_from": "SBI-CUSTOM-TREASURY-01",
        "account_to": "HDFC-BENEFICIARY-77",
        "amount_usd": 5000000.0,
        "authorization_type": "VOICE_CALL"
    })
    assert res_transfer.status_code == 200
    tx_data = res_transfer.json()
    assert "transaction_id" in tx_data and "audit_entry_id" in tx_data
    print(f"  [OK] 8. INR Wire Transfer Gatekeeper API: Approved & Logged ({tx_data['audit_entry_id']})")

    # 7. Test Cryptographic Audit Ledger & Chain Integrity
    res_logs = client.get("/api/v1/banking/audit-logs?limit=5")
    assert res_logs.status_code == 200 and len(res_logs.json()) >= 1
    print(f"  [OK] 9. Cryptographic Audit Ledger API: Fetched {len(res_logs.json())} Blocks")

    res_verify = client.get("/api/v1/banking/verify-ledger")
    assert res_verify.status_code == 200 and res_verify.json()["ledger_intact"] is True
    print(f"  [OK] 10. Ledger SHA-256 Chain Integrity: VERIFIED INTACT")

    print("=" * 80)
    print("[AUDIT SUCCESS] All 10 End-to-End System, Web & API Layers Verified 100% Operational!")
    print("=" * 80)


if __name__ == "__main__":
    verify_system_and_web()
