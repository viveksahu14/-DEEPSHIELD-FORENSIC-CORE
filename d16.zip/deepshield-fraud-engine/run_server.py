import os
import sys
import socket
import uvicorn

root_dir = os.path.dirname(os.path.abspath(__file__))
os.chdir(root_dir)

if root_dir not in sys.path:
    sys.path.insert(0, root_dir)


def find_available_port(start_port: int = 8000, max_attempts: int = 20) -> int:
    for port in range(start_port, start_port + max_attempts):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            try:
                s.bind(("127.0.0.1", port))
                return port
            except OSError:
                continue
    return start_port


if __name__ == "__main__":
    port = find_available_port(8000)

    print("=" * 70)
    print("[DEEPSHIELD] Fraud Detection Microservice Engine")
    print(f"[DASHBOARD]  http://127.0.0.1:{port}")
    print(f"[API DOCS]   http://127.0.0.1:{port}/docs")
    print("=" * 70)

    uvicorn.run("backend.app:app", host="127.0.0.1", port=port, app_dir=root_dir, reload=False)
