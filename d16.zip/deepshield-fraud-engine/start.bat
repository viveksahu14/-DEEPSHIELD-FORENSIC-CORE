@echo off
cd /d "%~dp0"
echo ======================================================================
echo Starting DeepShield Server...
echo ======================================================================
python run_server.py
pause
