# DeepShield - Engineering Architecture & DSP Specification

---

## 1. Acoustic Signal Processing

Synthetic speech models (HiFi-GAN, MelGAN, WaveGlow, Diffusion Vocoders) introduce characteristic anomalies in frequency and phase representations.

### 1.1 Neural Vocoder High-Frequency Brick-Wall Cutoff
Synthesizers trained on bandlimited speech (e.g. 16kHz sample rate with an effective 7kHz cutoff) lack natural acoustic roll-off:
$$\text{CutoffRatio} = \frac{\int_{f_{\text{cutoff}}}^{f_{\text{Nyquist}}} |X(f, t)| df}{\int_{f_{\text{mid}}}^{f_{\text{cutoff}}} |X(f, t)| df}$$
Threshold: $\text{CutoffRatio} < 0.035$ flags artificial band-limiting.

### 1.2 Spectral Flatness (Wiener Entropy)
Organic human speech concentrates acoustic power along resonant vocal tract formants:
$$\text{Flatness}(t) = \frac{\exp\left(\frac{1}{K}\sum_{k=0}^{K-1} \ln |X(k, t)|^2\right)}{\frac{1}{K}\sum_{k=0}^{K-1} |X(k, t)|^2}$$

### 1.3 Instantaneous Phase Derivative Variance
Organic vocal folds maintain smooth phase trajectories across voiced frames:
$$\Delta \phi(k, t) = \text{angle}(X(k, t)) - \text{angle}(X(k, t-1)) \pmod{2\pi}$$
$$\text{PhaseAnomaly} = \text{Var}_{k, t}(\Delta \phi(k, t))$$

---

## 2. Computer Vision & Micro-Expression Dynamics

### 2.1 Eye Aspect Ratio (EAR) Blink Kinematics
Eye openness calculated from vertical-to-horizontal eye geometry:
$$\text{EAR} = \frac{\|p_2 - p_6\| + \|p_3 - p_5\|}{2 \|p_1 - p_4\|}$$
Normal human blinking occurs at 12–24 BPM. Deepfake video streams typically display:
- **Static mask anomaly**: $< 4\text{ BPM}$
- **Synthetic flutter**: $> 40\text{ BPM}$

### 2.2 Boundary Blending Seam Energy
Face-swap pipelines leave boundary gradient discontinuities $\partial\Omega$:
$$\text{GradientRatio} = \frac{\frac{1}{|\partial\Omega|}\iint_{\partial\Omega} |\nabla^2 I| dxdy}{\frac{1}{|\Omega^\circ|}\iint_{\Omega^\circ} |\nabla^2 I| dxdy}$$

---

## 3. Audio-Visual Lip-Sync Cross-Correlation

Measures cross-modal synchronization between Short-Time Energy $E_A(t)$ and Mouth Aspect Ratio $\text{MAR}(t)$:
$$\rho_{A, V}(\tau) = \frac{\sum_t (E_A(t) - \bar{E}_A)(\text{MAR}(t + \tau) - \overline{\text{MAR}})}{\sigma_A \sigma_V}$$
- Estimated lag: $\tau^* = \arg\max_\tau \rho_{A, V}(\tau)$
- Flagged when $|\tau^*| > 120\text{ms}$ or $\max_\tau \rho_{A, V}(\tau) < 0.30$.

---

## 4. Cryptographic Audit Chain

Each transaction is recorded in an append-only ledger with SHA-256 block hashing:
$$H_0 = \text{SHA256}(\text{"GENESIS\_BLOCK"})$$
$$H_i = \text{SHA256}(T_i \,\|\, \text{RiskScore}_i \,\|\, \text{Decision}_i \,\|\, H_{i-1})$$
