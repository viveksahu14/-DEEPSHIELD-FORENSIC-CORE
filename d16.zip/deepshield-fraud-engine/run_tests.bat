@echo off
cd /d "%~dp0"
echo ======================================================================
echo Running DeepShield Tests...
echo ======================================================================
python run_tests.py
pause
