document.addEventListener('DOMContentLoaded', async () => {
  const btn = document.getElementById('openDashboardBtn');
  if (btn) {
    btn.addEventListener('click', () => {
      chrome.tabs.create({ url: 'http://127.0.0.1:8000' });
    });
  }

  try {
    const res = await fetch('http://127.0.0.1:8000/api/v1/banking/audit-logs?limit=1');
    if (res.ok) {
      const logs = await res.json();
      if (logs && logs.length > 0) {
        const latest = logs[0];
        document.getElementById('riskScore').textContent = latest.risk_score.toFixed(1);
        const label = document.getElementById('riskLabel');
        label.textContent = `${latest.risk_level} (${latest.decision})`;
        if (latest.risk_level === 'CRITICAL' || latest.risk_level === 'HIGH') {
          label.style.color = '#ff1744';
        } else if (latest.risk_level === 'MEDIUM') {
          label.style.color = '#ffab00';
        } else {
          label.style.color = '#00e676';
        }
      }
    }
  } catch (e) {
    console.log('Background engine standby:', e);
  }
});
