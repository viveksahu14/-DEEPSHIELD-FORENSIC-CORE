// In-page banking interceptor HUD badge
(function() {
  const badge = document.createElement('div');
  badge.id = 'deepshield-inpage-badge';
  badge.innerHTML = `
    <div style="position:fixed;bottom:20px;right:20px;background:#0b1120;border:1px solid #00f2fe;border-radius:30px;padding:8px 14px;color:#00f2fe;font-family:monospace;font-size:12px;font-weight:bold;display:flex;align-items:center;gap:8px;box-shadow:0 0 16px rgba(0,242,254,0.3);z-index:999999;cursor:pointer;">
      <span style="width:8px;height:8px;border-radius:50%;background:#00e676;display:inline-block;box-shadow:0 0 6px #00e676;"></span>
      <span>DEEPSHIELD PROTECTED</span>
    </div>
  `;
  document.body.appendChild(badge);
})();
