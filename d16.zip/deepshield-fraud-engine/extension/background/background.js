chrome.runtime.onInstalled.addListener(() => {
  console.log('[DeepShield] Background fraud protection worker active.');
});

chrome.runtime.onMessage.addListener((req, sender, sendResponse) => {
  if (req.type === 'CHECK_TRANSACTION') {
    fetch('http://127.0.0.1:8000/api/v1/banking/authorize-transfer', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(req.payload)
    })
      .then(r => r.json())
      .then(data => sendResponse({ success: true, data }))
      .catch(err => sendResponse({ success: false, error: err.message }));
    return true;
  }
});
