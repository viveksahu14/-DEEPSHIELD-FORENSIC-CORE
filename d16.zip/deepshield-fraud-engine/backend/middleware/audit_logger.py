import hashlib
import json
import time
from typing import List, Optional
from pydantic import BaseModel


class AuditEntry(BaseModel):
    entry_id: str
    timestamp: float
    iso_time: str
    event_type: str
    transaction_id: Optional[str] = None
    account_from: Optional[str] = None
    account_to: Optional[str] = None
    amount_usd: Optional[float] = None
    risk_score: float
    risk_level: str
    decision: str
    forensic_summary: str
    previous_hash: str
    current_hash: str


class CryptographicAuditLog:
    GENESIS_HASH = "GENESIS_BLOCK_00000000000000000000000000000000000000000000000000"

    def __init__(self):
        self._entries: List[AuditEntry] = []
        self._last_hash: str = self.GENESIS_HASH

    def record_event(
        self,
        event_type: str,
        risk_score: float,
        risk_level: str,
        decision: str,
        forensic_summary: str,
        transaction_id: Optional[str] = None,
        account_from: Optional[str] = None,
        account_to: Optional[str] = None,
        amount_usd: Optional[float] = None,
    ) -> AuditEntry:
        now = time.time()
        iso = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(now))
        entry_id = f"AUD-{int(now * 1000)}-{len(self._entries) + 1}"

        payload = {
            "entry_id": entry_id,
            "timestamp": now,
            "event_type": event_type,
            "transaction_id": transaction_id,
            "account_from": account_from,
            "account_to": account_to,
            "amount_usd": amount_usd,
            "risk_score": risk_score,
            "risk_level": risk_level,
            "decision": decision,
            "forensic_summary": forensic_summary,
            "previous_hash": self._last_hash,
        }

        entry_hash = hashlib.sha256(json.dumps(payload, sort_keys=True).encode("utf-8")).hexdigest()

        entry = AuditEntry(
            entry_id=entry_id,
            timestamp=now,
            iso_time=iso,
            event_type=event_type,
            transaction_id=transaction_id,
            account_from=account_from,
            account_to=account_to,
            amount_usd=amount_usd,
            risk_score=risk_score,
            risk_level=risk_level,
            decision=decision,
            forensic_summary=forensic_summary,
            previous_hash=self._last_hash,
            current_hash=entry_hash,
        )

        self._entries.append(entry)
        self._last_hash = entry_hash
        return entry

    def get_recent_entries(self, limit: int = 50) -> List[AuditEntry]:
        return list(reversed(self._entries[-limit:]))

    def verify_integrity(self) -> bool:
        prev = self.GENESIS_HASH
        for entry in self._entries:
            if entry.previous_hash != prev:
                return False
            payload = {
                "entry_id": entry.entry_id,
                "timestamp": entry.timestamp,
                "event_type": entry.event_type,
                "transaction_id": entry.transaction_id,
                "account_from": entry.account_from,
                "account_to": entry.account_to,
                "amount_usd": entry.amount_usd,
                "risk_score": entry.risk_score,
                "risk_level": entry.risk_level,
                "decision": entry.decision,
                "forensic_summary": entry.forensic_summary,
                "previous_hash": entry.previous_hash,
            }
            computed = hashlib.sha256(json.dumps(payload, sort_keys=True).encode("utf-8")).hexdigest()
            if computed != entry.current_hash:
                return False
            prev = entry.current_hash
        return True


audit_log = CryptographicAuditLog()
