import uuid
from typing import Optional, List
from pydantic import BaseModel, Field

from backend.config import settings
from backend.analyzer.engine import master_engine, MultimodalRiskReport
from backend.middleware.audit_logger import audit_log


class TransferAuthorizationRequest(BaseModel):
    transaction_id: Optional[str] = None
    account_from: str
    account_to: str
    amount_usd: float
    initiator_role: str = "Corporate Treasury"
    authorization_type: str = "VOICE_CALL"
    raw_audio_base64: Optional[str] = None
    raw_video_frames_base64: Optional[List[str]] = None


class TransferAuthorizationResponse(BaseModel):
    transaction_id: str
    decision: str
    is_blocked: bool
    risk_score: float
    risk_level: str
    step_up_required: bool
    step_up_method: Optional[str] = None
    authorization_token: Optional[str] = None
    forensic_reasons: List[str]
    audit_entry_id: str
    message: str


class BankingFraudGatekeeper:
    def __init__(self):
        self.engine = master_engine
        self.audit = audit_log

    def evaluate_transfer(
        self,
        request: TransferAuthorizationRequest,
        risk_report: MultimodalRiskReport
    ) -> TransferAuthorizationResponse:
        tx_id = request.transaction_id or f"TXN-{uuid.uuid4().hex[:10].upper()}"
        amount = request.amount_usd
        risk = risk_report.overall_risk_score

        effective_risk = risk
        if amount >= settings.fraud_policy.mandatory_mfa_usd and risk >= 25.0:
            effective_risk = min(100.0, risk * 1.25)

        reasons = list(risk_report.aggregated_artifacts)

        if effective_risk >= settings.fraud_policy.high_risk_threshold:
            decision = "REJECTED_BLOCKED"
            is_blocked = True
            step_up = False
            step_up_method = None
            token = None
            message = f"🚨 TRANSFER INTERCEPTED & BLOCKED: Deepfake fraud detected with {risk_report.risk_level} risk score ({effective_risk:.1f}/100)."
            event_type = "FRAUD_BLOCKED"
        elif effective_risk >= settings.fraud_policy.low_risk_threshold:
            decision = "CHALLENGED"
            is_blocked = False
            step_up = True
            step_up_method = "OUT_OF_BAND_HARDWARE_MFA_AND_OFFICER_CALLBACK"
            token = None
            message = f"⚠️ TRANSFER SUSPENDED: Medium synthetic risk detected ({effective_risk:.1f}/100). Step-up authentication required."
            event_type = "STEP_UP_CHALLENGED"
            reasons.append("Elevated synthetic anomaly score requires dual-custody verification.")
        else:
            decision = "APPROVED"
            is_blocked = False
            step_up = False
            step_up_method = None
            token = f"AUTH-SIG-{uuid.uuid4().hex.upper()}"
            message = "✅ TRANSFER AUTHORIZED: Media stream verified authentic."
            event_type = "TRANSFER_AUTHORIZED"

        audit_entry = self.audit.record_event(
            event_type=event_type,
            risk_score=effective_risk,
            risk_level=risk_report.risk_level,
            decision=decision,
            forensic_summary=risk_report.forensic_summary,
            transaction_id=tx_id,
            account_from=request.account_from,
            account_to=request.account_to,
            amount_usd=request.amount_usd
        )

        return TransferAuthorizationResponse(
            transaction_id=tx_id,
            decision=decision,
            is_blocked=is_blocked,
            risk_score=round(effective_risk, 2),
            risk_level=risk_report.risk_level,
            step_up_required=step_up,
            step_up_method=step_up_method,
            authorization_token=token,
            forensic_reasons=reasons,
            audit_entry_id=audit_entry.entry_id,
            message=message
        )


banking_gatekeeper = BankingFraudGatekeeper()
