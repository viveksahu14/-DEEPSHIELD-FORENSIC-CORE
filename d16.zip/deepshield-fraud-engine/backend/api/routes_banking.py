import os
import time
import uuid
from typing import List, Dict, Any, Optional
from fastapi import APIRouter, HTTPException, Query, UploadFile, File, Form

from backend.api.schemas import (
    TransferAuthorizationRequest,
    TransferAuthorizationResponse,
    SimulationScenarioRequest,
    AuditEntry,
)
from backend.middleware.banking_interceptor import banking_gatekeeper
from backend.middleware.audit_logger import audit_log
from backend.analyzer.engine import master_engine, MultimodalRiskReport
from backend.analyzer.spectral_audio import SpectralAudioReport
from backend.analyzer.video_microexpression import MicroExpressionReport
from backend.analyzer.lipsync_discrepancy import LipSyncReport
from backend.utils.audio_utils import load_audio_bytes
from backend.utils.video_utils import extract_frames_from_video_bytes

router = APIRouter(prefix="/api/v1/banking", tags=["Banking Security"])


def _generate_synthetic_spectrogram_grid(is_cutoff: bool = True) -> List[List[float]]:
    grid = []
    for r in range(24):
        row = []
        for c in range(32):
            if is_cutoff and r > 16:
                val = 5.0 + ((r * c) % 8)
            else:
                val = 30.0 + 60.0 * abs(((r * 3 + c * 5) % 20) / 20.0)
            row.append(round(val, 1))
        grid.append(row)
    return grid


@router.post("/authorize-transfer", response_model=TransferAuthorizationResponse)
async def authorize_wire_transfer(request: TransferAuthorizationRequest):
    try:
        risk_report = master_engine.analyze_media(audio_array=None, frames=None)
        return banking_gatekeeper.evaluate_transfer(request, risk_report)
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Transfer authorization error: {str(e)}")


@router.post("/authorize-multimodal-transfer")
async def authorize_multimodal_transfer(
    account_from: str = Form("HDFC-CORP-98812 (Treasury Desk)"),
    account_to: str = Form("ICICI-BENEFICIARY-44102 (Offshore)"),
    amount_usd: float = Form(2500000.0),
    authorization_type: str = Form("VOICE_CALL"),
    scenario_preset: Optional[str] = Form(None),
    audio_file: Optional[UploadFile] = File(None),
    video_file: Optional[UploadFile] = File(None),
):
    try:
        audio_arr = None
        sr = 16000
        frames = None

        if audio_file is not None and getattr(audio_file, "filename", None):
            a_bytes = await audio_file.read()
            if len(a_bytes) > 0:
                audio_arr, sr = load_audio_bytes(a_bytes)

        if video_file is not None and getattr(video_file, "filename", None):
            v_bytes = await video_file.read()
            if len(v_bytes) > 0:
                frames = extract_frames_from_video_bytes(v_bytes)

        if audio_arr is not None or frames is not None:
            risk_report = master_engine.analyze_media(
                audio_array=audio_arr,
                frames=frames,
                audio_sr=sr,
                video_fps=30.0
            )
        elif scenario_preset:
            sim_res = await simulate_fraud_scenario(SimulationScenarioRequest(
                scenario=scenario_preset,
                account_from=account_from,
                account_to=account_to,
                transfer_amount_usd=amount_usd
            ))
            return sim_res
        else:
            # Fallback to high-risk analysis if suspicious high amount or run standard baseline
            risk_report = master_engine.analyze_media(audio_array=None, frames=None)

        req = TransferAuthorizationRequest(
            account_from=account_from,
            account_to=account_to,
            amount_usd=amount_usd,
            authorization_type=authorization_type
        )
        auth_decision = banking_gatekeeper.evaluate_transfer(req, risk_report)

        return {
            "scenario": scenario_preset or "custom_multimodal",
            "risk_report": risk_report.model_dump(),
            "authorization_decision": auth_decision.model_dump()
        }
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Multimodal authorization error: {str(e)}")


@router.get("/audit-logs", response_model=List[AuditEntry])
async def get_audit_logs(limit: int = Query(default=20, le=100)):
    return audit_log.get_recent_entries(limit=limit)


@router.get("/verify-ledger")
async def verify_ledger_integrity():
    valid = audit_log.verify_integrity()
    return {
        "ledger_intact": valid,
        "total_records": len(audit_log._entries),
        "last_hash": audit_log._last_hash,
        "compliance_status": "VERIFIED_TAMPER_EVIDENT" if valid else "CORRUPTED"
    }


@router.post("/simulate-scenario", response_model=Dict[str, Any])
async def simulate_fraud_scenario(req: SimulationScenarioRequest):
    scenario = req.scenario.lower()

    if scenario == "authentic_ceo":
        audio_rep = SpectralAudioReport(
            is_synthetic=False,
            risk_score=7.5,
            confidence=0.96,
            high_frequency_cutoff_detected=False,
            spectral_flatness_score=0.12,
            phase_flux_anomaly=0.08,
            harmonic_distortion_score=0.05,
            detected_artifacts=[],
            spectrogram_preview=_generate_synthetic_spectrogram_grid(is_cutoff=False),
            forensic_summary="Natural harmonic formant spectrum and organic phase flux verified."
        )
        video_rep = MicroExpressionReport(
            is_synthetic=False,
            risk_score=9.0,
            confidence=0.94,
            blink_rate_bpm=16.5,
            blink_anomaly_detected=False,
            landmark_jitter_score=0.012,
            boundary_seam_score=0.08,
            skin_texture_anomaly=0.05,
            detected_artifacts=[],
            ear_timeline=[0.28, 0.29, 0.28, 0.12, 0.28, 0.29, 0.28, 0.14, 0.29, 0.28, 0.29, 0.12, 0.28, 0.29],
            mar_timeline=[0.18, 0.32, 0.45, 0.22, 0.15, 0.38, 0.20, 0.35, 0.42, 0.18, 0.15, 0.36, 0.22, 0.18],
            forensic_summary="Biological involuntary blink dynamics (16.5 BPM) and pore skin variance confirmed."
        )
        lipsync_rep = LipSyncReport(
            is_desynchronized=False,
            risk_score=6.0,
            confidence=0.95,
            sync_lag_ms=18.0,
            viseme_correlation_score=0.88,
            detected_artifacts=[],
            audio_energy_timeline=[0.2, 0.6, 0.8, 0.4, 0.2, 0.7, 0.9, 0.3, 0.2, 0.6, 0.8, 0.3],
            mar_motion_timeline=[0.22, 0.58, 0.82, 0.38, 0.21, 0.68, 0.88, 0.32, 0.19, 0.59, 0.81, 0.29],
            forensic_summary="Phoneme acoustics and mouth visemes are in tight synchronization."
        )
        risk_score, risk_level, action, artifacts = 8.6, "LOW", "ALLOW", []

    elif scenario == "voice_clone_wire_fraud":
        audio_rep = SpectralAudioReport(
            is_synthetic=True,
            risk_score=94.2,
            confidence=0.98,
            high_frequency_cutoff_detected=True,
            spectral_flatness_score=0.78,
            phase_flux_anomaly=0.85,
            harmonic_distortion_score=0.72,
            detected_artifacts=[
                "Neural Vocoder Frequency Brick-Wall Cutoff (< 7000 Hz)",
                "Phase Coherence Discontinuity (HiFi-GAN / Diffusion Vocoder Artifact)",
                "Abnormal Spectral Flatness / Artificial Floor Noise"
            ],
            spectrogram_preview=_generate_synthetic_spectrogram_grid(is_cutoff=True),
            forensic_summary="AI voice clone signature detected: HiFi-GAN vocoder cutoff at 7.0 kHz and phase jitter."
        )
        video_rep = MicroExpressionReport(
            is_synthetic=False,
            risk_score=25.0,
            confidence=0.80,
            blink_rate_bpm=15.0,
            blink_anomaly_detected=False,
            landmark_jitter_score=0.02,
            boundary_seam_score=0.10,
            skin_texture_anomaly=0.12,
            detected_artifacts=[],
            ear_timeline=[0.28, 0.29, 0.12, 0.28, 0.29, 0.28, 0.14, 0.29, 0.28, 0.29],
            mar_timeline=[0.20, 0.35, 0.20, 0.35, 0.20, 0.35, 0.20, 0.35, 0.20, 0.35],
            forensic_summary="Video telemetry stream active."
        )
        lipsync_rep = LipSyncReport(
            is_desynchronized=True,
            risk_score=72.0,
            confidence=0.90,
            sync_lag_ms=140.0,
            viseme_correlation_score=0.28,
            detected_artifacts=["Synthetic Acoustic-Visual Temporal Offset (140.0ms)"],
            audio_energy_timeline=[0.1, 0.8, 0.9, 0.2, 0.1, 0.8, 0.9, 0.2],
            mar_motion_timeline=[0.1, 0.1, 0.8, 0.9, 0.2, 0.1, 0.8, 0.9],
            forensic_summary="Synthetic audio dubbing temporal offset detected."
        )
        risk_score, risk_level, action, artifacts = 92.4, "CRITICAL", "BLOCK", audio_rep.detected_artifacts

    elif scenario == "deepfake_video_kyc":
        audio_rep = SpectralAudioReport(
            is_synthetic=False,
            risk_score=20.0,
            confidence=0.82,
            high_frequency_cutoff_detected=False,
            spectral_flatness_score=0.22,
            phase_flux_anomaly=0.15,
            harmonic_distortion_score=0.12,
            detected_artifacts=[],
            spectrogram_preview=_generate_synthetic_spectrogram_grid(is_cutoff=False),
            forensic_summary="Audio acoustic frequencies appear organic."
        )
        video_rep = MicroExpressionReport(
            is_synthetic=True,
            risk_score=89.5,
            confidence=0.97,
            blink_rate_bpm=2.1,
            blink_anomaly_detected=True,
            landmark_jitter_score=0.082,
            boundary_seam_score=0.79,
            skin_texture_anomaly=0.84,
            detected_artifacts=[
                "Static Eye Anomaly (Blink rate: 2.1 BPM, expected 12-24 BPM)",
                "Face-Swap Boundary Blending Discontinuity",
                "Diffusion/GAN Over-Smoothed Facial Skin Texture"
            ],
            ear_timeline=[0.29, 0.28, 0.29, 0.28, 0.29, 0.29, 0.28, 0.29, 0.28, 0.29, 0.29, 0.28],
            mar_timeline=[0.20, 0.21, 0.20, 0.22, 0.20, 0.21, 0.20, 0.22, 0.20, 0.21, 0.20, 0.22],
            forensic_summary="Deepfake video detected: absence of involuntary blinks and perimeter blending seam."
        )
        lipsync_rep = LipSyncReport(
            is_desynchronized=True,
            risk_score=68.0,
            confidence=0.88,
            sync_lag_ms=160.0,
            viseme_correlation_score=0.22,
            detected_artifacts=["Mouth Motion Viseme Decoupling"],
            audio_energy_timeline=[0.2, 0.7, 0.8, 0.3, 0.2, 0.7, 0.8, 0.3],
            mar_motion_timeline=[0.1, 0.2, 0.2, 0.2, 0.1, 0.2, 0.2, 0.2],
            forensic_summary="Frozen mouth motion decoupled from incoming acoustic energy."
        )
        risk_score, risk_level, action, artifacts = 88.7, "CRITICAL", "BLOCK", video_rep.detected_artifacts

    else:
        audio_rep = SpectralAudioReport(
            is_synthetic=False,
            risk_score=22.0,
            confidence=0.85,
            high_frequency_cutoff_detected=False,
            spectral_flatness_score=0.25,
            phase_flux_anomaly=0.20,
            harmonic_distortion_score=0.18,
            detected_artifacts=[],
            spectrogram_preview=_generate_synthetic_spectrogram_grid(is_cutoff=False),
            forensic_summary="Audio acoustic spectrum appears organic."
        )
        video_rep = MicroExpressionReport(
            is_synthetic=False,
            risk_score=28.0,
            confidence=0.86,
            blink_rate_bpm=14.0,
            blink_anomaly_detected=False,
            landmark_jitter_score=0.02,
            boundary_seam_score=0.15,
            skin_texture_anomaly=0.20,
            detected_artifacts=[],
            ear_timeline=[0.28, 0.29, 0.14, 0.28, 0.29, 0.28, 0.14, 0.29, 0.28, 0.29],
            mar_timeline=[0.15, 0.40, 0.15, 0.40, 0.15, 0.40, 0.15, 0.40, 0.15, 0.40],
            forensic_summary="Video stream exhibits normal facial dynamics."
        )
        lipsync_rep = LipSyncReport(
            is_desynchronized=True,
            risk_score=78.5,
            confidence=0.92,
            sync_lag_ms=285.0,
            viseme_correlation_score=0.12,
            detected_artifacts=[
                "Viseme-Phoneme Decoupling (Correlation: 0.12)",
                "Acoustic-Visual Temporal Offset (285.0ms lag)"
            ],
            audio_energy_timeline=[0.1, 0.9, 0.8, 0.2, 0.1, 0.9, 0.8, 0.2, 0.1, 0.9, 0.8, 0.2],
            mar_motion_timeline=[0.1, 0.1, 0.2, 0.8, 0.9, 0.2, 0.1, 0.1, 0.2, 0.8, 0.9, 0.2],
            forensic_summary="Severe phoneme-viseme desynchronization. Speech acoustics decoupled from mouth motion."
        )
        risk_score, risk_level, action, artifacts = 48.5, "MEDIUM", "STEP_UP_AUTH", lipsync_rep.detected_artifacts

    risk_report = MultimodalRiskReport(
        analysis_id=f"SIM-{uuid.uuid4().hex[:8].upper()}",
        timestamp=time.time(),
        is_deepfake=risk_score >= 30.0,
        overall_risk_score=risk_score,
        risk_level=risk_level,
        confidence=0.96,
        recommended_action=action,
        audio_report=audio_rep,
        video_report=video_rep,
        lipsync_report=lipsync_rep,
        aggregated_artifacts=artifacts,
        forensic_summary=f"Simulation result for '{scenario}': {risk_level} risk score ({risk_score}/100)."
    )

    transfer_req = TransferAuthorizationRequest(
        account_from=req.account_from,
        account_to=req.account_to,
        amount_usd=req.transfer_amount_usd,
        initiator_role="Corporate Executive",
        authorization_type="VOICE_CALL_AND_VIDEO"
    )

    auth_response = banking_gatekeeper.evaluate_transfer(transfer_req, risk_report)

    return {
        "scenario": scenario,
        "risk_report": risk_report.model_dump(),
        "authorization_decision": auth_response.model_dump()
    }
