from typing import List, Optional
from pydantic import BaseModel


class SpectralAudioReport(BaseModel):
    is_synthetic: bool
    risk_score: float
    confidence: float
    high_frequency_cutoff_detected: bool
    spectral_flatness_score: float
    phase_flux_anomaly: float
    harmonic_distortion_score: float
    detected_artifacts: List[str]
    spectrogram_preview: List[List[float]] = []
    forensic_summary: str


class MicroExpressionReport(BaseModel):
    is_synthetic: bool
    risk_score: float
    confidence: float
    blink_rate_bpm: float
    blink_anomaly_detected: bool
    landmark_jitter_score: float
    boundary_seam_score: float
    skin_texture_anomaly: float
    detected_artifacts: List[str]
    ear_timeline: List[float] = []
    mar_timeline: List[float] = []
    forensic_summary: str


class LipSyncReport(BaseModel):
    is_desynchronized: bool
    risk_score: float
    confidence: float
    sync_lag_ms: float
    viseme_correlation_score: float
    detected_artifacts: List[str]
    audio_energy_timeline: List[float] = []
    mar_motion_timeline: List[float] = []
    forensic_summary: str


class MultimodalRiskReport(BaseModel):
    analysis_id: str
    timestamp: float
    is_deepfake: bool
    overall_risk_score: float
    risk_level: str
    confidence: float
    recommended_action: str
    audio_report: Optional[SpectralAudioReport] = None
    video_report: Optional[MicroExpressionReport] = None
    lipsync_report: Optional[LipSyncReport] = None
    aggregated_artifacts: List[str]
    forensic_summary: str


class TransferAuthorizationRequest(BaseModel):
    transaction_id: Optional[str] = None
    account_from: str
    account_to: str
    amount_usd: float
    initiator_role: str = "Corporate Treasury"
    authorization_type: str = "VOICE_CALL"
    raw_audio_base64: Optional[str] = None
    raw_video_frames_base64: Optional[List[str]] = None


class TransferAuthorizationResponse(BaseModel):
    transaction_id: str
    decision: str
    is_blocked: bool
    risk_score: float
    risk_level: str
    step_up_required: bool
    step_up_method: Optional[str] = None
    authorization_token: Optional[str] = None
    forensic_reasons: List[str]
    audit_entry_id: str
    message: str


class StreamFrameRequest(BaseModel):
    session_id: Optional[str] = None
    frame_base64: str
    audio_chunk_base64: Optional[str] = None


class StreamFrameResponse(BaseModel):
    session_id: str
    timestamp: float
    current_risk_score: float
    risk_level: str
    is_anomaly_detected: bool
    active_threats: List[str]
    ear: float
    mar: float
    audio_rms: float
    message: str


class SimulationScenarioRequest(BaseModel):
    scenario: str
    transfer_amount_usd: float = 2500000.0
    account_from: str = "HDFC-CORP-TREASURY-98812"
    account_to: str = "ICICI-OFFSHORE-44102"


class AuditEntry(BaseModel):
    entry_id: str
    timestamp: float
    iso_time: str
    event_type: str
    transaction_id: Optional[str] = None
    account_from: Optional[str] = None
    account_to: Optional[str] = None
    amount_usd: Optional[float] = None
    risk_score: float
    risk_level: str
    decision: str
    forensic_summary: str
    previous_hash: str
    current_hash: str


class HealthResponse(BaseModel):
    status: str
    engine: str
    version: str
    active_workers: int
    timestamp: float
