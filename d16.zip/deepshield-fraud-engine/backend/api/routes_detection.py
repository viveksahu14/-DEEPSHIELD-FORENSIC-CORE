import time
import uuid
import json
from typing import Optional
from fastapi import APIRouter, UploadFile, File, WebSocket, WebSocketDisconnect, HTTPException
import numpy as np

from backend.api.schemas import (
    SpectralAudioReport,
    MicroExpressionReport,
    MultimodalRiskReport,
    StreamFrameRequest,
    StreamFrameResponse,
)
from backend.analyzer.engine import master_engine
from backend.utils.audio_utils import load_audio_bytes
from backend.utils.video_utils import extract_frames_from_video_bytes, decode_base64_frame, FaceFeatureExtractor

router = APIRouter(prefix="/api/v1/detect", tags=["Detection"])
extractor = FaceFeatureExtractor()


@router.post("/audio", response_model=SpectralAudioReport)
async def detect_audio(file: UploadFile = File(...)):
    try:
        content = await file.read()
        audio_arr, sr = load_audio_bytes(content)
        return master_engine.audio_analyzer.analyze(audio_arr, sr=sr)
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Audio analysis failed: {str(e)}")


@router.post("/video", response_model=MicroExpressionReport)
async def detect_video(file: UploadFile = File(...)):
    try:
        content = await file.read()
        frames = extract_frames_from_video_bytes(content)
        return master_engine.video_analyzer.analyze_frames(frames, fps=30.0)
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Video analysis failed: {str(e)}")


@router.post("/multimodal", response_model=MultimodalRiskReport)
async def detect_multimodal(
    audio_file: Optional[UploadFile] = File(None),
    video_file: Optional[UploadFile] = File(None),
):
    try:
        audio_arr = None
        sr = 16000
        frames = None

        if audio_file is not None and getattr(audio_file, "filename", None):
            a_bytes = await audio_file.read()
            if len(a_bytes) > 0:
                audio_arr, sr = load_audio_bytes(a_bytes)

        if video_file is not None and getattr(video_file, "filename", None):
            v_bytes = await video_file.read()
            if len(v_bytes) > 0:
                frames = extract_frames_from_video_bytes(v_bytes)

        if audio_arr is None and frames is None:
            # If empty file or direct post, run simulation benchmark
            return master_engine.analyze_media(audio_array=None, frames=None)

        return master_engine.analyze_media(
            audio_array=audio_arr,
            frames=frames,
            audio_sr=sr,
            video_fps=30.0
        )
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Multimodal analysis error: {str(e)}")


@router.post("/stream-frame", response_model=StreamFrameResponse)
async def analyze_stream_frame(payload: StreamFrameRequest):
    try:
        session_id = payload.session_id or f"SES-{uuid.uuid4().hex[:8]}"
        frame = decode_base64_frame(payload.frame_base64)
        box = extractor.detect_face(frame)
        threats = []
        ear, mar = 0.25, 0.20
        seam, skin = 0.0, 0.0

        if box:
            x, y, w, h = box
            roi = frame[max(0, y): min(frame.shape[0], y+h), max(0, x): min(frame.shape[1], x+w)]
            ear, mar, _ = extractor.compute_ear_and_mar(roi)
            seam = extractor.compute_boundary_seam_gradient(frame, box)
            skin = extractor.compute_skin_texture_smoothness(roi)

            if seam > 0.48: threats.append("Face Boundary Blending Artifact")
            if skin > 0.65: threats.append("Over-smoothed Diffusion Skin Texture")

        risk = round(float(np.clip((seam * 50.0) + (skin * 40.0), 0.0, 100.0)), 2)
        level = "CRITICAL" if risk >= 85 else "HIGH" if risk >= 65 else "MEDIUM" if risk >= 30 else "LOW"

        return StreamFrameResponse(
            session_id=session_id,
            timestamp=time.time(),
            current_risk_score=risk,
            risk_level=level,
            is_anomaly_detected=risk >= 30.0,
            active_threats=threats,
            ear=round(ear, 3),
            mar=round(mar, 3),
            audio_rms=0.0,
            message="Frame analyzed"
        )
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Streaming analysis error: {str(e)}")


@router.websocket("/ws/live-stream")
async def websocket_live_stream(websocket: WebSocket):
    await websocket.accept()
    try:
        while True:
            raw = await websocket.receive_text()
            try:
                msg = json.loads(raw)
            except Exception:
                continue

            if msg.get("type") == "ping":
                await websocket.send_text(json.dumps({"type": "pong", "timestamp": time.time()}))
                continue

            frame_b64 = msg.get("frame")
            if frame_b64:
                try:
                    frame = decode_base64_frame(frame_b64)
                    box = extractor.detect_face(frame)
                    ear, mar = 0.25, 0.20
                    seam, skin = 0.0, 0.0
                    threats = []

                    if box:
                        x, y, w, h = box
                        roi = frame[max(0, y): min(frame.shape[0], y+h), max(0, x): min(frame.shape[1], x+w)]
                        ear, mar, _ = extractor.compute_ear_and_mar(roi)
                        seam = extractor.compute_boundary_seam_gradient(frame, box)
                        skin = extractor.compute_skin_texture_smoothness(roi)
                        if seam > 0.48: threats.append("Face-Swap Boundary Seam")
                        if skin > 0.65: threats.append("Diffusion Face Texture")

                    risk = round(float(np.clip((seam * 50.0) + (skin * 40.0), 0.0, 100.0)), 2)
                    level = "CRITICAL" if risk >= 85 else "HIGH" if risk >= 65 else "MEDIUM" if risk >= 30 else "LOW"

                    await websocket.send_text(json.dumps({
                        "type": "telemetry",
                        "timestamp": time.time(),
                        "risk_score": risk,
                        "risk_level": level,
                        "face_detected": box is not None,
                        "ear": round(ear, 3),
                        "mar": round(mar, 3),
                        "boundary_seam": round(seam, 3),
                        "skin_smoothness": round(skin, 3),
                        "threats": threats
                    }))
                except Exception:
                    pass
    except WebSocketDisconnect:
        pass
    except Exception:
        pass
