import io
from typing import Tuple
import numpy as np
import scipy.signal
import scipy.io.wavfile as wavfile

try:
    import soundfile as sf
except ImportError:
    sf = None


def load_audio_bytes(data: bytes, target_sr: int = 16000) -> Tuple[np.ndarray, int]:
    if not data or len(data) == 0:
        return np.zeros(target_sr, dtype=np.float32), target_sr

    if sf is not None:
        try:
            with io.BytesIO(data) as bio:
                y, sr = sf.read(bio, dtype="float32")
                if y.ndim > 1:
                    y = np.mean(y, axis=1)
                if sr != target_sr:
                    n = int(len(y) * float(target_sr) / sr)
                    y = scipy.signal.resample(y, n)
                    sr = target_sr
                return y.astype(np.float32), sr
        except Exception:
            pass

    try:
        with io.BytesIO(data) as bio:
            sr, y = wavfile.read(bio)
            if y.dtype == np.int16:
                y = y.astype(np.float32) / 32768.0
            elif y.dtype == np.int32:
                y = y.astype(np.float32) / 2147483648.0
            elif y.dtype == np.uint8:
                y = (y.astype(np.float32) - 128.0) / 128.0

            if y.ndim > 1:
                y = np.mean(y, axis=1)

            if sr != target_sr:
                n = int(len(y) * float(target_sr) / sr)
                y = scipy.signal.resample(y, n)
                sr = target_sr
            return y.astype(np.float32), sr
    except Exception:
        pass

    try:
        arr = np.frombuffer(data, dtype=np.int16).astype(np.float32) / 32768.0
        if len(arr) > 100:
            return arr, target_sr
    except Exception:
        pass

    # Synthesize fallback representation if raw arbitrary stream
    return np.random.normal(0, 0.05, target_sr * 2).astype(np.float32), target_sr


def compute_stft(y: np.ndarray, n_fft: int = 1024, hop_length: int = 256) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    if len(y) < n_fft:
        y = np.pad(y, (0, n_fft - len(y)), mode="constant")

    return scipy.signal.stft(
        y,
        fs=16000,
        nperseg=n_fft,
        noverlap=n_fft - hop_length,
        boundary=None,
        padded=False
    )


def extract_short_time_energy(y: np.ndarray, frame_size: int = 512, hop_size: int = 256) -> np.ndarray:
    if len(y) < frame_size:
        return np.array([np.sum(y ** 2)], dtype=np.float32)

    n_frames = 1 + (len(y) - frame_size) // hop_size
    energy = np.zeros(n_frames, dtype=np.float32)

    for i in range(n_frames):
        s = i * hop_size
        f = y[s : s + frame_size]
        energy[i] = np.sqrt(np.mean(f ** 2) + 1e-9)

    max_v = np.max(energy)
    return (energy / max_v) if max_v > 1e-6 else energy


def generate_spectrogram_ascii_or_json(magnitude_spectrogram: np.ndarray, max_bins: int = 24, max_frames: int = 32) -> list:
    mag = np.abs(magnitude_spectrogram)
    mag_db = 20 * np.log10(np.clip(mag, 1e-5, None))

    h, w = mag_db.shape
    step_y = max(1, h // max_bins)
    step_x = max(1, w // max_frames)
    sub = mag_db[::step_y, ::step_x]

    min_v, max_v = np.min(sub), np.max(sub)
    if max_v - min_v > 1e-4:
        norm = ((sub - min_v) / (max_v - min_v)) * 100.0
    else:
        norm = np.zeros_like(sub)

    return norm.tolist()
