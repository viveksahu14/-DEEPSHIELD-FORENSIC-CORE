import os
import cv2
import base64
import tempfile
from typing import List, Tuple, Dict, Any, Optional
import numpy as np


class FaceFeatureExtractor:
    def __init__(self):
        c_dir = getattr(cv2, "data", None)
        c_path = getattr(c_dir, "haarcascades", "") if c_dir else ""

        f_xml = os.path.join(c_path, "haarcascade_frontalface_default.xml")
        e_xml = os.path.join(c_path, "haarcascade_eye.xml")
        s_xml = os.path.join(c_path, "haarcascade_smile.xml")

        self.face_cascade = cv2.CascadeClassifier(f_xml) if os.path.exists(f_xml) else cv2.CascadeClassifier()
        self.eye_cascade = cv2.CascadeClassifier(e_xml) if os.path.exists(e_xml) else cv2.CascadeClassifier()
        self.smile_cascade = cv2.CascadeClassifier(s_xml) if os.path.exists(s_xml) else cv2.CascadeClassifier()

    def detect_face(self, frame: np.ndarray) -> Optional[Tuple[int, int, int, int]]:
        h, w = frame.shape[:2]
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY) if frame.ndim == 3 else frame

        if not self.face_cascade.empty():
            try:
                faces = self.face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(60, 60))
                if len(faces) > 0:
                    faces = sorted(faces, key=lambda f: f[2] * f[3], reverse=True)
                    return tuple(faces[0])
            except Exception:
                pass

        cx, cy = w // 2, h // 2
        sz = min(w, h) // 2
        return (max(0, cx - sz // 2), max(0, cy - sz // 2), sz, sz)

    def compute_ear_and_mar(self, face_roi: np.ndarray) -> Tuple[float, float, Dict[str, Any]]:
        if face_roi.size == 0:
            return 0.25, 0.20, {}

        gray = cv2.cvtColor(face_roi, cv2.COLOR_BGR2GRAY) if face_roi.ndim == 3 else face_roi
        h, w = gray.shape

        eyes = []
        if not self.eye_cascade.empty():
            try:
                zone = gray[int(h * 0.18) : int(h * 0.55), int(w * 0.10) : int(w * 0.90)]
                eyes = self.eye_cascade.detectMultiScale(zone, scaleFactor=1.1, minNeighbors=3, minSize=(15, 15))
            except Exception:
                eyes = []

        if len(eyes) >= 1:
            ear_list = [eh / float(ew) if ew > 0 else 0.25 for (ex, ey, ew, eh) in eyes[:2]]
            ear = float(np.mean(ear_list))
        else:
            up_zone = gray[int(h * 0.25) : int(h * 0.48), int(w * 0.20) : int(w * 0.80)]
            grad_y = np.std(cv2.Sobel(up_zone, cv2.CV_64F, 0, 1, ksize=3))
            ear = float(np.clip(grad_y / 140.0, 0.10, 0.35))

        smiles = []
        if not self.smile_cascade.empty():
            try:
                m_zone = gray[int(h * 0.60) : int(h * 0.95), int(w * 0.20) : int(w * 0.80)]
                smiles = self.smile_cascade.detectMultiScale(m_zone, scaleFactor=1.3, minNeighbors=8, minSize=(20, 10))
            except Exception:
                smiles = []

        if len(smiles) >= 1:
            (sx, sy, sw, sh) = smiles[0]
            mar = float(sh / float(sw)) if sw > 0 else 0.20
        else:
            m_zone = gray[int(h * 0.60) : int(h * 0.95), int(w * 0.20) : int(w * 0.80)]
            thresh = cv2.adaptiveThreshold(m_zone, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY_INV, 11, 2)
            mar = float(np.clip((np.sum(thresh > 0) / float(m_zone.size + 1e-6)) * 1.5, 0.05, 0.85))

        return ear, mar, {"ear": round(ear, 4), "mar": round(mar, 4)}

    def compute_boundary_seam_gradient(self, frame: np.ndarray, face_box: Tuple[int, int, int, int]) -> float:
        x, y, w, h = face_box
        H, W = frame.shape[:2]

        pad_x, pad_y = int(w * 0.12), int(h * 0.12)
        x1, y1 = max(0, x - pad_x), max(0, y - pad_y)
        x2, y2 = min(W, x + w + pad_x), min(H, y + h + pad_y)

        sub = frame[y1:y2, x1:x2]
        if sub.size == 0:
            return 0.0

        gray = cv2.cvtColor(sub, cv2.COLOR_BGR2GRAY) if sub.ndim == 3 else sub
        lap = cv2.Laplacian(gray, cv2.CV_64F)

        mask = np.zeros_like(gray, dtype=np.uint8)
        cv2.rectangle(
            mask,
            (pad_x, pad_y),
            (sub.shape[1] - pad_x, sub.shape[0] - pad_y),
            255,
            thickness=max(2, int(w * 0.05))
        )

        seam_e = np.mean(np.abs(lap[mask > 0])) if np.sum(mask) > 0 else 0.0
        int_e = np.mean(np.abs(lap[mask == 0])) if np.sum(mask == 0) > 0 else 1.0

        ratio = seam_e / (int_e + 1e-6)
        return float(np.clip((ratio - 0.8) / 1.5, 0.0, 1.0))

    def compute_skin_texture_smoothness(self, face_roi: np.ndarray) -> float:
        if face_roi.size == 0:
            return 0.5

        gray = cv2.cvtColor(face_roi, cv2.COLOR_BGR2GRAY) if face_roi.ndim == 3 else face_roi
        h, w = gray.shape

        left = gray[int(h * 0.45) : int(h * 0.65), int(w * 0.15) : int(w * 0.35)]
        right = gray[int(h * 0.45) : int(h * 0.65), int(w * 0.65) : int(w * 0.85)]

        vars_ = []
        if left.size > 0: vars_.append(float(np.var(left)))
        if right.size > 0: vars_.append(float(np.var(right)))

        if not vars_:
            return 0.5

        avg_v = np.mean(vars_)
        return float(np.clip(1.0 - (avg_v / 20.0), 0.0, 1.0)) if avg_v < 20.0 else 0.0


def decode_base64_frame(data_url: str) -> np.ndarray:
    if "," in data_url:
        data_url = data_url.split(",")[1]
    raw = base64.b64decode(data_url)
    arr = np.frombuffer(raw, dtype=np.uint8)
    img = cv2.imdecode(arr, cv2.IMREAD_COLOR)
    if img is None:
        raise ValueError("Corrupt image data")
    return img


def extract_frames_from_video_bytes(video_bytes: bytes, max_frames: int = 150) -> List[np.ndarray]:
    with tempfile.NamedTemporaryFile(suffix=".mp4", delete=False) as tmp:
        tmp.write(video_bytes)
        tmp_path = tmp.name

    frames = []
    try:
        cap = cv2.VideoCapture(tmp_path)
        total = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        stride = max(1, total // max_frames) if total > max_frames else 1

        count = 0
        while cap.isOpened() and len(frames) < max_frames:
            ret, frame = cap.read()
            if not ret:
                break
            if count % stride == 0:
                frames.append(frame)
            count += 1
        cap.release()
    finally:
        if os.path.exists(tmp_path):
            try:
                os.remove(tmp_path)
            except Exception:
                pass

    return frames
