from typing import List
import numpy as np
import scipy.signal
from pydantic import BaseModel, Field

from backend.config import settings
from backend.utils.audio_utils import extract_short_time_energy


class LipSyncReport(BaseModel):
    is_desynchronized: bool
    risk_score: float
    confidence: float
    sync_lag_ms: float
    viseme_correlation_score: float
    detected_artifacts: List[str]
    audio_energy_timeline: List[float] = Field(default_factory=list)
    mar_motion_timeline: List[float] = Field(default_factory=list)
    forensic_summary: str


class LipSyncDiscrepancyAnalyzer:
    def __init__(self, config=None):
        self.cfg = config or settings.lipsync

    def analyze(
        self,
        audio_arr: np.ndarray,
        mar_seq: List[float],
        audio_sr: int = 16000,
        video_fps: float = 30.0
    ) -> LipSyncReport:
        if len(audio_arr) == 0 or len(mar_seq) < 5:
            return LipSyncReport(
                is_desynchronized=False,
                risk_score=0.0,
                confidence=0.0,
                sync_lag_ms=0.0,
                viseme_correlation_score=1.0,
                detected_artifacts=["Insufficient multimodal sample length"],
                forensic_summary="Insufficient audio or video frames for lip-sync analysis."
            )

        hop = int(audio_sr / video_fps)
        a_energy = extract_short_time_energy(audio_arr, frame_size=hop * 2, hop_size=hop)

        min_len = min(len(a_energy), len(mar_seq))
        if min_len < 5:
            min_len = max(len(a_energy), len(mar_seq))
            a_env = np.pad(a_energy, (0, max(0, min_len - len(a_energy))), mode="edge")
            v_mar = np.pad(mar_seq, (0, max(0, min_len - len(mar_seq))), mode="edge")
        else:
            a_env = a_energy[:min_len]
            v_mar = np.array(mar_seq[:min_len], dtype=np.float32)

        a_std = np.std(a_env)
        v_std = np.std(v_mar)

        if a_std < 1e-5 or v_std < 1e-5:
            corr_score = 0.10
            sync_lag_ms = 0.0
        else:
            a_norm = (a_env - np.mean(a_env)) / a_std
            v_norm = (v_mar - np.mean(v_mar)) / v_std

            max_lag_frames = int(video_fps * 0.5)
            corr = scipy.signal.correlate(v_norm, a_norm, mode="full") / len(a_norm)
            lags = scipy.signal.correlation_lags(len(v_norm), len(a_norm), mode="full")

            valid = np.abs(lags) <= max_lag_frames
            if np.any(valid):
                v_corr = corr[valid]
                v_lags = lags[valid]
                best_idx = np.argmax(v_corr)
                best_lag = v_lags[best_idx]
                peak_corr = float(v_corr[best_idx])
            else:
                best_lag = 0
                peak_corr = 0.0

            sync_lag_ms = float((best_lag / video_fps) * 1000.0)
            corr_score = float(np.clip(peak_corr, 0.0, 1.0))

        artifacts = []
        is_desync = False

        if corr_score < self.cfg.min_viseme_correlation:
            is_desync = True
            artifacts.append(f"Viseme-Phoneme Decoupling (Correlation: {round(corr_score, 2)})")

        if abs(sync_lag_ms) > self.cfg.max_sync_lag_ms:
            is_desync = True
            direction = "lead" if sync_lag_ms < 0 else "lag"
            artifacts.append(f"Acoustic-Visual Temporal Offset ({abs(round(sync_lag_ms, 1))}ms {direction})")

        lag_risk = float(np.clip((abs(sync_lag_ms) - 60.0) / 150.0, 0.0, 1.0)) * 50.0
        corr_risk = float(np.clip((0.60 - corr_score) / 0.50, 0.0, 1.0)) * 50.0
        risk = round(float(np.clip(lag_risk + corr_risk, 0.0, 100.0)), 2)
        conf = round(min(0.99, 0.55 + (risk / 200.0)), 2)

        summary = (
            f"Acoustics and mouth kinematics are in tight synchronization (Lag: {round(sync_lag_ms, 1)}ms, Correlation: {round(corr_score, 2)})."
            if not artifacts else
            f"Detected {len(artifacts)} synchronization anomalies: {', '.join(artifacts)}."
        )

        step = max(1, len(a_env) // 40)
        return LipSyncReport(
            is_desynchronized=is_desync,
            risk_score=risk,
            confidence=conf,
            sync_lag_ms=round(sync_lag_ms, 1),
            viseme_correlation_score=round(corr_score, 3),
            detected_artifacts=artifacts,
            audio_energy_timeline=[round(float(v), 3) for v in a_env[::step]],
            mar_motion_timeline=[round(float(v), 3) for v in v_mar[::step]],
            forensic_summary=summary
        )
