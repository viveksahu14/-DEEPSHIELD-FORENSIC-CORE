from typing import List
import numpy as np
import cv2
from pydantic import BaseModel, Field

from backend.config import settings
from backend.utils.video_utils import FaceFeatureExtractor


class MicroExpressionReport(BaseModel):
    is_synthetic: bool
    risk_score: float
    confidence: float
    blink_rate_bpm: float
    blink_anomaly_detected: bool
    landmark_jitter_score: float
    boundary_seam_score: float
    skin_texture_anomaly: float
    detected_artifacts: List[str]
    ear_timeline: List[float] = Field(default_factory=list)
    mar_timeline: List[float] = Field(default_factory=list)
    forensic_summary: str


class VideoMicroExpressionAnalyzer:
    def __init__(self, config=None):
        self.cfg = config or settings.video
        self.extractor = FaceFeatureExtractor()

    def analyze_frames(self, frames: List[np.ndarray], fps: float = 30.0) -> MicroExpressionReport:
        if not frames:
            return MicroExpressionReport(
                is_synthetic=False,
                risk_score=0.0,
                confidence=0.0,
                blink_rate_bpm=0.0,
                blink_anomaly_detected=False,
                landmark_jitter_score=0.0,
                boundary_seam_score=0.0,
                skin_texture_anomaly=0.0,
                detected_artifacts=["No video frames provided"],
                forensic_summary="No video frames received for analysis."
            )

        ears, mars, seams, skins, boxes = [], [], [], [], []

        for frame in frames:
            box = self.extractor.detect_face(frame)
            if box is not None:
                x, y, w, h = box
                boxes.append(box)
                roi = frame[max(0, y): min(frame.shape[0], y+h), max(0, x): min(frame.shape[1], x+w)]
                ear, mar, _ = self.extractor.compute_ear_and_mar(roi)
                ears.append(ear)
                mars.append(mar)
                seams.append(self.extractor.compute_boundary_seam_gradient(frame, box))
                skins.append(self.extractor.compute_skin_texture_smoothness(roi))
            else:
                ears.append(0.25)
                mars.append(0.20)
                seams.append(0.0)
                skins.append(0.0)

        duration_sec = max(1.0, len(frames) / float(fps))

        blinks = 0
        in_blink = False
        for val in ears:
            if val < self.cfg.blink_ear_threshold and not in_blink:
                in_blink = True
                blinks += 1
            elif val >= self.cfg.blink_ear_threshold and in_blink:
                in_blink = False

        bpm = (blinks / duration_sec) * 60.0
        blink_anomaly = False
        artifacts = []

        if duration_sec >= 1.5:
            if bpm < self.cfg.abnormal_blink_rate_min:
                blink_anomaly = True
                artifacts.append(f"Static Eye Anomaly (Blink rate: {round(bpm, 1)} BPM, expected 12-24 BPM)")
            elif bpm > self.cfg.abnormal_blink_rate_max:
                blink_anomaly = True
                artifacts.append(f"Synthetic Eyelid Flutter ({round(bpm, 1)} BPM)")

        if len(boxes) > 2:
            centers = np.array([[b[0] + b[2]/2.0, b[1] + b[3]/2.0] for b in boxes])
            diffs = np.diff(centers, axis=0)
            avg_w = np.mean([b[2] for b in boxes]) + 1e-6
            jitter_norm = np.mean(np.linalg.norm(diffs, axis=1)) / avg_w
            jitter_score = float(np.clip((jitter_norm - 0.02) / 0.06, 0.0, 1.0))
        else:
            jitter_score = 0.0

        if jitter_score > self.cfg.landmark_jitter_threshold:
            artifacts.append("Facial Warping / Landmark Micro-Jitter")

        avg_seam = float(np.mean(seams)) if seams else 0.0
        if avg_seam > self.cfg.boundary_seam_threshold:
            artifacts.append("Face-Swap Boundary Blending Discontinuity")

        avg_skin = float(np.mean(skins)) if skins else 0.0
        if avg_skin > self.cfg.skin_texture_smoothness_threshold:
            artifacts.append("Diffusion/GAN Over-Smoothed Facial Skin Texture")

        raw_score = (
            (30.0 if blink_anomaly else 0.0) +
            (30.0 * avg_seam) +
            (20.0 * jitter_score) +
            (20.0 * avg_skin)
        )
        risk = round(float(np.clip(raw_score, 0.0, 100.0)), 2)
        is_synth = risk >= settings.fraud_policy.low_risk_threshold
        conf = round(min(0.99, 0.50 + (risk / 200.0)), 2)

        summary = (
            "Facial dynamics, involuntary blink intervals, and skin pore textures match biological baseline."
            if not artifacts else
            f"Detected {len(artifacts)} visual anomalies: {', '.join(artifacts)}."
        )

        step = max(1, len(ears) // 50)
        return MicroExpressionReport(
            is_synthetic=is_synth,
            risk_score=risk,
            confidence=conf,
            blink_rate_bpm=round(bpm, 1),
            blink_anomaly_detected=blink_anomaly,
            landmark_jitter_score=round(jitter_score, 4),
            boundary_seam_score=round(avg_seam, 4),
            skin_texture_anomaly=round(avg_skin, 4),
            detected_artifacts=artifacts,
            ear_timeline=[round(float(v), 3) for v in ears[::step]],
            mar_timeline=[round(float(v), 3) for v in mars[::step]],
            forensic_summary=summary
        )
