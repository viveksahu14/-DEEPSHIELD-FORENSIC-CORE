from typing import List
import numpy as np
import scipy.signal
from pydantic import BaseModel, Field

from backend.config import settings
from backend.utils.audio_utils import compute_stft, generate_spectrogram_ascii_or_json


class SpectralAudioReport(BaseModel):
    is_synthetic: bool
    risk_score: float
    confidence: float
    high_frequency_cutoff_detected: bool
    spectral_flatness_score: float
    phase_flux_anomaly: float
    harmonic_distortion_score: float
    detected_artifacts: List[str]
    spectrogram_preview: List[List[float]] = Field(default_factory=list)
    forensic_summary: str


class SpectralAudioAnalyzer:
    def __init__(self, config=None):
        self.cfg = config or settings.audio

    def analyze(self, audio_arr: np.ndarray, sr: int = 16000) -> SpectralAudioReport:
        if len(audio_arr) == 0:
            return SpectralAudioReport(
                is_synthetic=False,
                risk_score=0.0,
                confidence=0.0,
                high_frequency_cutoff_detected=False,
                spectral_flatness_score=0.0,
                phase_flux_anomaly=0.0,
                harmonic_distortion_score=0.0,
                detected_artifacts=["Empty audio stream"],
                forensic_summary="No audio signal received."
            )

        f, t, Zxx = compute_stft(audio_arr, n_fft=self.cfg.n_fft, hop_length=self.cfg.hop_length)
        mag = np.abs(Zxx)
        phase = np.angle(Zxx)

        artifacts = []

        # 1. Vocoder cutoff check
        hi_mask = f >= self.cfg.high_freq_threshold_hz
        mid_mask = (f >= 1000.0) & (f < self.cfg.high_freq_threshold_hz)
        hi_e = np.mean(mag[hi_mask, :]) if np.any(hi_mask) else 0.0
        mid_e = np.mean(mag[mid_mask, :]) if np.any(mid_mask) else 1.0

        cutoff_ratio = hi_e / (mid_e + 1e-7)
        has_cutoff = bool(cutoff_ratio < 0.035 and mid_e > 0.001)
        if has_cutoff:
            artifacts.append(f"Neural Vocoder Frequency Brick-Wall Cutoff (< {int(self.cfg.high_freq_threshold_hz)} Hz)")

        # 2. Wiener spectral flatness
        pwr = mag ** 2 + 1e-12
        geom = np.exp(np.mean(np.log(pwr), axis=0))
        arith = np.mean(pwr, axis=0)
        flatness_mean = float(np.mean(geom / (arith + 1e-12)))

        flatness_score = float(np.clip((flatness_mean - 0.05) / 0.35, 0.0, 1.0))
        if flatness_score > self.cfg.synthetic_flatness_threshold:
            artifacts.append("Abnormal Spectral Flatness / Artificial Floor Noise")

        # 3. Phase flux derivative continuity
        if phase.shape[1] > 2:
            d_phi = np.diff(phase, axis=1)
            unwrapped = (d_phi + np.pi) % (2 * np.pi) - np.pi
            phase_var = float(np.var(unwrapped))
            phase_score = float(np.clip((phase_var - 1.8) / 1.5, 0.0, 1.0))
        else:
            phase_score = 0.0

        if phase_score > self.cfg.phase_flux_anomaly_threshold:
            artifacts.append("Phase Coherence Discontinuity (HiFi-GAN / Diffusion Vocoder Artifact)")

        # 4. Cepstral peak prominence
        cep = np.real(np.fft.ifft(np.log(np.clip(mag, 1e-6, None)), axis=0))
        q_range = cep[40:200, :]
        cpp = np.max(np.abs(q_range), axis=0) if q_range.shape[0] > 0 else np.zeros(1)
        cpp_std = float(np.std(cpp)) if len(cpp) > 1 else 0.5

        harm_score = float(np.clip(1.0 - (cpp_std / 0.4), 0.0, 1.0))
        if harm_score > self.cfg.harmonic_distortion_threshold:
            artifacts.append("Artificial Glottal Pulse / Monotone Pitch Invariance")

        raw = (
            (35.0 if has_cutoff else 0.0) +
            (25.0 * flatness_score) +
            (25.0 * phase_score) +
            (15.0 * harm_score)
        )
        risk = round(float(np.clip(raw, 0.0, 100.0)), 2)
        is_synth = risk >= settings.fraud_policy.low_risk_threshold
        conf = round(min(0.99, 0.50 + (risk / 200.0)), 2)

        summary = (
            "Acoustic spectrum shows organic vocal tract resonances, normal spectral roll-off, and healthy phase flux."
            if not artifacts else
            f"Detected {len(artifacts)} synthetic acoustic indicators: {', '.join(artifacts)}."
        )

        return SpectralAudioReport(
            is_synthetic=is_synth,
            risk_score=risk,
            confidence=conf,
            high_frequency_cutoff_detected=has_cutoff,
            spectral_flatness_score=round(flatness_score, 4),
            phase_flux_anomaly=round(phase_score, 4),
            harmonic_distortion_score=round(harm_score, 4),
            detected_artifacts=artifacts,
            spectrogram_preview=generate_spectrogram_ascii_or_json(mag, max_bins=24, max_frames=32),
            forensic_summary=summary
        )
