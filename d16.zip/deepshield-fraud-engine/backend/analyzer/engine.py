import time
import uuid
from typing import List, Optional
import numpy as np
from pydantic import BaseModel, Field

from backend.config import settings
from backend.analyzer.spectral_audio import SpectralAudioAnalyzer, SpectralAudioReport
from backend.analyzer.video_microexpression import VideoMicroExpressionAnalyzer, MicroExpressionReport
from backend.analyzer.lipsync_discrepancy import LipSyncDiscrepancyAnalyzer, LipSyncReport


class MultimodalRiskReport(BaseModel):
    analysis_id: str
    timestamp: float
    is_deepfake: bool
    overall_risk_score: float = Field(..., description="Combined risk score from 0.0 to 100.0")
    risk_level: str = Field(..., description="LOW, MEDIUM, HIGH, or CRITICAL")
    confidence: float
    recommended_action: str = Field(..., description="ALLOW, STEP_UP_AUTH, or BLOCK")
    audio_report: Optional[SpectralAudioReport] = None
    video_report: Optional[MicroExpressionReport] = None
    lipsync_report: Optional[LipSyncReport] = None
    aggregated_artifacts: List[str]
    forensic_summary: str


class DeepShieldMasterEngine:
    def __init__(self):
        self.audio_analyzer = SpectralAudioAnalyzer()
        self.video_analyzer = VideoMicroExpressionAnalyzer()
        self.lipsync_analyzer = LipSyncDiscrepancyAnalyzer()

    def analyze_media(
        self,
        audio_array: Optional[np.ndarray] = None,
        frames: Optional[List[np.ndarray]] = None,
        audio_sr: int = 16000,
        video_fps: float = 30.0
    ) -> MultimodalRiskReport:
        analysis_id = str(uuid.uuid4())
        now = time.time()

        audio_rep = None
        video_rep = None
        lipsync_rep = None

        weighted_score = 0.0
        total_weight = 0.0
        all_artifacts = []

        if audio_array is not None and len(audio_array) > 0:
            audio_rep = self.audio_analyzer.analyze(audio_array, sr=audio_sr)
            w = settings.weights["audio_spectral"]
            total_weight += w
            weighted_score += audio_rep.risk_score * w
            all_artifacts.extend(audio_rep.detected_artifacts)

        mar_sequence = []
        if frames is not None and len(frames) > 0:
            video_rep = self.video_analyzer.analyze_frames(frames, fps=video_fps)
            w = settings.weights["video_microexpression"]
            total_weight += w
            weighted_score += video_rep.risk_score * w
            all_artifacts.extend(video_rep.detected_artifacts)
            mar_sequence = video_rep.mar_timeline

        if audio_array is not None and len(audio_array) > 0 and len(mar_sequence) > 0:
            lipsync_rep = self.lipsync_analyzer.analyze(
                audio_arr=audio_array,
                mar_seq=mar_sequence,
                audio_sr=audio_sr,
                video_fps=video_fps
            )
            w = settings.weights["lipsync_discrepancy"]
            total_weight += w
            weighted_score += lipsync_rep.risk_score * w
            all_artifacts.extend(lipsync_rep.detected_artifacts)

        overall_score = round(weighted_score / total_weight, 2) if total_weight > 0 else 0.0

        policy = settings.fraud_policy
        if overall_score >= policy.critical_risk_threshold:
            risk_level = "CRITICAL"
            action = "BLOCK"
        elif overall_score >= policy.high_risk_threshold:
            risk_level = "HIGH"
            action = "BLOCK"
        elif overall_score >= policy.low_risk_threshold:
            risk_level = "MEDIUM"
            action = "STEP_UP_AUTH"
        else:
            risk_level = "LOW"
            action = "ALLOW"

        is_deepfake = overall_score >= policy.low_risk_threshold

        conf_scores = [r.confidence for r in (audio_rep, video_rep, lipsync_rep) if r is not None]
        avg_confidence = round(float(np.mean(conf_scores)), 2) if conf_scores else 0.85

        unique_artifacts = list(dict.fromkeys(all_artifacts))
        if not unique_artifacts:
            summary = "Media stream verified authentic. No synthetic acoustic or visual manipulation markers found."
        else:
            summary = f"Flagged with {risk_level} risk ({overall_score}/100). Found {len(unique_artifacts)} threat indicators: {'; '.join(unique_artifacts)}."

        return MultimodalRiskReport(
            analysis_id=analysis_id,
            timestamp=now,
            is_deepfake=is_deepfake,
            overall_risk_score=overall_score,
            risk_level=risk_level,
            confidence=avg_confidence,
            recommended_action=action,
            audio_report=audio_rep,
            video_report=video_rep,
            lipsync_report=lipsync_rep,
            aggregated_artifacts=unique_artifacts,
            forensic_summary=summary
        )


master_engine = DeepShieldMasterEngine()
