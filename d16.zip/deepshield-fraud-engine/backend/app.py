import os
import time
from fastapi import FastAPI, Response
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse

from backend.config import settings
from backend.api.routes_detection import router as detection_router
from backend.api.routes_banking import router as banking_router
from backend.api.schemas import HealthResponse

app = FastAPI(
    title=settings.app_name,
    version=settings.version,
    description="Real-Time Deepfake Voice & Media Detection Engine for Financial Fraud Prevention",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(detection_router)
app.include_router(banking_router)

frontend_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "frontend")
if os.path.exists(frontend_dir):
    app.mount("/static", StaticFiles(directory=frontend_dir), name="static")


@app.get("/favicon.ico", include_in_schema=False)
async def favicon():
    return Response(status_code=204)


@app.get("/", include_in_schema=False)
async def serve_index():
    index_file = os.path.join(frontend_dir, "index.html")
    return FileResponse(index_file) if os.path.exists(index_file) else {"error": "UI build missing"}


@app.get("/api/v1/health", response_model=HealthResponse, tags=["System"])
async def health_check():
    return HealthResponse(
        status="HEALTHY",
        engine="DeepShield DSP & Vision Core",
        version=settings.version,
        active_workers=1,
        timestamp=time.time()
    )
