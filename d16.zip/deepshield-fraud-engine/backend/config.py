import os
from dataclasses import dataclass, field
from typing import Dict


@dataclass
class AudioConfig:
    sample_rate: int = 16000
    n_fft: int = 1024
    hop_length: int = 256
    n_mels: int = 80
    high_freq_threshold_hz: float = 7000.0
    synthetic_flatness_threshold: float = 0.45
    phase_flux_anomaly_threshold: float = 0.60
    harmonic_distortion_threshold: float = 0.55


@dataclass
class VideoConfig:
    target_fps: int = 30
    min_face_size: int = 64
    blink_ear_threshold: float = 0.21
    abnormal_blink_rate_max: float = 40.0
    abnormal_blink_rate_min: float = 4.0
    landmark_jitter_threshold: float = 0.035
    boundary_seam_threshold: float = 0.48
    skin_texture_smoothness_threshold: float = 0.65


@dataclass
class LipSyncConfig:
    max_sync_lag_ms: float = 120.0
    min_viseme_correlation: float = 0.30
    energy_mar_coupling_threshold: float = 0.35


@dataclass
class FraudPolicyConfig:
    low_risk_threshold: float = 30.0
    high_risk_threshold: float = 65.0
    critical_risk_threshold: float = 85.0
    high_value_transaction_usd: float = 1000000.0  # ₹10 Lakhs
    mandatory_mfa_usd: float = 5000000.0          # ₹50 Lakhs
    auto_block_usd: float = 10000000.0            # ₹1 Crore


@dataclass
class AppConfig:
    app_name: str = "DeepShield Fraud Detection Engine"
    version: str = "1.0.0"
    debug: bool = os.getenv("DEBUG", "false").lower() == "true"
    weights: Dict[str, float] = field(
        default_factory=lambda: {
            "audio_spectral": 0.40,
            "video_microexpression": 0.35,
            "lipsync_discrepancy": 0.25,
        }
    )
    audio: AudioConfig = field(default_factory=AudioConfig)
    video: VideoConfig = field(default_factory=VideoConfig)
    lipsync: LipSyncConfig = field(default_factory=LipSyncConfig)
    fraud_policy: FraudPolicyConfig = field(default_factory=FraudPolicyConfig)


settings = AppConfig()
