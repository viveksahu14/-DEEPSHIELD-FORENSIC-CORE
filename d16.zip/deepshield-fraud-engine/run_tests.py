import os
import sys

root_dir = os.path.dirname(os.path.abspath(__file__))
if root_dir not in sys.path:
    sys.path.insert(0, root_dir)

import numpy as np
from fastapi.testclient import TestClient

from backend.app import app
from backend.analyzer.spectral_audio import SpectralAudioAnalyzer
from backend.analyzer.video_microexpression import VideoMicroExpressionAnalyzer
from backend.analyzer.lipsync_discrepancy import LipSyncDiscrepancyAnalyzer
from backend.middleware.banking_interceptor import banking_gatekeeper, TransferAuthorizationRequest
from backend.middleware.audit_logger import audit_log
from backend.analyzer.engine import master_engine
from backend.utils.audio_utils import load_audio_bytes
import cv2

client = TestClient(app)


def test_empty_audio():
    analyzer = SpectralAudioAnalyzer()
    rep = analyzer.analyze(np.array([], dtype=np.float32))
    assert rep.risk_score == 0.0
    assert not rep.is_synthetic


def test_pristine_voice_detection():
    analyzer = SpectralAudioAnalyzer()
    path = os.path.join(root_dir, "fixtures", "pristine_voice.wav")
    with open(path, "rb") as f:
        y, sr = load_audio_bytes(f.read())
    rep = analyzer.analyze(y, sr=sr)
    assert rep.risk_score < 50.0


def test_synthetic_voice_clone_detection():
    analyzer = SpectralAudioAnalyzer()
    path = os.path.join(root_dir, "fixtures", "synthetic_clone_voice.wav")
    with open(path, "rb") as f:
        y, sr = load_audio_bytes(f.read())
    rep = analyzer.analyze(y, sr=sr)
    assert rep.risk_score >= 60.0
    assert rep.high_frequency_cutoff_detected is True


def test_video_microexpression_analysis():
    analyzer = VideoMicroExpressionAnalyzer()
    f_dir = os.path.join(root_dir, "fixtures", "synthetic_frames")
    frames = [cv2.imread(os.path.join(f_dir, f"frame_{i:03d}.png")) for i in range(60)]
    rep = analyzer.analyze_frames(frames, fps=30.0)
    assert rep.blink_anomaly_detected is True


def test_lipsync_synchronized():
    analyzer = LipSyncDiscrepancyAnalyzer()
    sr, fps, dur = 16000, 30.0, 2.0
    t_a = np.linspace(0, dur, int(sr * dur))
    t_v = np.linspace(0, dur, int(fps * dur))

    audio = (np.sin(2 * np.pi * 3.0 * t_a) ** 2) * np.sin(2 * np.pi * 200.0 * t_a)
    mar = 0.2 + 0.3 * (np.sin(2 * np.pi * 3.0 * t_v) ** 2)

    rep = analyzer.analyze(audio_arr=audio.astype(np.float32), mar_seq=mar.tolist(), audio_sr=sr, video_fps=fps)
    assert rep.is_desynchronized is False
    assert rep.viseme_correlation_score >= 0.30


def test_lipsync_desynchronized():
    analyzer = LipSyncDiscrepancyAnalyzer()
    sr, fps, dur = 16000, 30.0, 2.0
    t_a = np.linspace(0, dur, int(sr * dur))
    t_v = np.linspace(0, dur, int(fps * dur))

    audio = (np.sin(2 * np.pi * 2.0 * t_a) ** 2) * np.sin(2 * np.pi * 200.0 * t_a)
    mar = 0.2 + 0.3 * (np.sin(2 * np.pi * 5.0 * t_v + 1.5) ** 2)

    rep = analyzer.analyze(audio_arr=audio.astype(np.float32), mar_seq=mar.tolist(), audio_sr=sr, video_fps=fps)
    assert rep.risk_score >= 30.0


def test_banking_middleware_low_risk():
    report = master_engine.analyze_media(audio_array=None, frames=None)
    report.overall_risk_score = 12.0
    report.risk_level = "LOW"

    req = TransferAuthorizationRequest(
        account_from="HDFC-CORP-098",
        account_to="ICICI-BENEFICIARY-114",
        amount_usd=25000.0
    )
    decision = banking_gatekeeper.evaluate_transfer(req, report)
    assert decision.decision == "APPROVED"
    assert decision.is_blocked is False
    assert decision.authorization_token is not None


def test_banking_middleware_high_risk_blocked():
    report = master_engine.analyze_media(audio_array=None, frames=None)
    report.overall_risk_score = 88.0
    report.risk_level = "CRITICAL"
    report.aggregated_artifacts = ["Neural Vocoder Frequency Brick-Wall Cutoff (< 7000 Hz)"]

    req = TransferAuthorizationRequest(
        account_from="HDFC-CORP-098",
        account_to="OFFSHORE-PANAMA-882",
        amount_usd=500000.0
    )
    decision = banking_gatekeeper.evaluate_transfer(req, report)
    assert decision.decision == "REJECTED_BLOCKED"
    assert decision.is_blocked is True


def test_cryptographic_audit_ledger_integrity():
    ledger = audit_log
    ledger._entries = []
    ledger._last_hash = ledger.GENESIS_HASH

    ledger.record_event("TX_1", 10.0, "LOW", "APPROVED", "Authentic voice verified", "TX-001", "ACC-A", "ACC-B", 5000.0)
    ledger.record_event("TX_2", 90.0, "CRITICAL", "BLOCKED", "Deepfake detected", "TX-002", "ACC-A", "OFFSHORE-X", 500000.0)

    assert len(ledger._entries) == 2
    assert ledger.verify_integrity() is True


def test_cryptographic_audit_ledger_tamper_detection():
    ledger = audit_log
    ledger._entries = []
    ledger._last_hash = ledger.GENESIS_HASH

    ledger.record_event("TX_1", 10.0, "LOW", "APPROVED", "Summary 1", "TX-001")
    ledger.record_event("TX_2", 85.0, "CRITICAL", "BLOCKED", "Summary 2", "TX-002")

    # Corrupt risk score
    ledger._entries[0].risk_score = 99.9
    assert ledger.verify_integrity() is False


def test_api_health():
    res = client.get("/api/v1/health")
    assert res.status_code == 200
    assert res.json()["status"] == "HEALTHY"


def test_api_scenario_simulation():
    res = client.post("/api/v1/banking/simulate-scenario", json={"scenario": "voice_clone_wire_fraud"})
    assert res.status_code == 200
    data = res.json()
    assert data["scenario"] == "voice_clone_wire_fraud"
    assert data["authorization_decision"]["is_blocked"] is True


def test_api_audit_logs():
    res = client.get("/api/v1/banking/audit-logs?limit=5")
    assert res.status_code == 200
    assert isinstance(res.json(), list)


def run_all_tests():
    tests = [
        ("1. Empty audio handling", test_empty_audio),
        ("2. Pristine voice verification", test_pristine_voice_detection),
        ("3. Synthetic voice clone cutoff", test_synthetic_voice_clone_detection),
        ("4. Video facial micro-expression", test_video_microexpression_analysis),
        ("5. Synchronized lip-sync", test_lipsync_synchronized),
        ("6. Desynchronized lip-sync", test_lipsync_desynchronized),
        ("7. Low-risk wire transfer approval", test_banking_middleware_low_risk),
        ("8. High-risk wire transfer block", test_banking_middleware_high_risk_blocked),
        ("9. Audit ledger SHA-256 integrity", test_cryptographic_audit_ledger_integrity),
        ("10. Audit ledger tamper detection", test_cryptographic_audit_ledger_tamper_detection),
        ("11. API Health endpoint", test_api_health),
        ("12. API Scenario simulation", test_api_scenario_simulation),
        ("13. API Audit logs endpoint", test_api_audit_logs),
    ]

    print("=" * 70)
    print("[DEEPSHIELD] Running 13 Automated Verification Tests...")
    print("=" * 70)

    passed = 0
    for name, fn in tests:
        try:
            fn()
            print(f"  [PASS] {name}")
            passed += 1
        except Exception as e:
            print(f"  [FAIL] {name}: {e}")

    print("=" * 70)
    print(f"[RESULTS] Passed: {passed}/{len(tests)}")
    print("=" * 70)
    return passed == len(tests)


if __name__ == "__main__":
    success = run_all_tests()
    sys.exit(0 if success else 1)
