import os
import numpy as np
import scipy.io.wavfile as wavfile
from scipy.signal import butter, sosfilt
import cv2


def generate_pristine_voice(filepath: str, duration: float = 2.5, sr: int = 16000):
    t = np.linspace(0, duration, int(sr * duration), endpoint=False)
    f0 = 130.0 + 3.0 * np.sin(2 * np.pi * 5.0 * t)
    phase = 2 * np.pi * np.cumsum(f0) / sr

    harmonics = np.zeros_like(t)
    for h in range(1, 35):
        freq = h * 130.0
        weight = 1.0 / (1.0 + ((freq - 500)/150)**2) + 0.6 / (1.0 + ((freq - 1500)/200)**2) + 0.3 / (1.0 + ((freq - 2500)/300)**2)
        weight += 0.05 / (1.0 + (freq / 6000.0)**2)
        harmonics += weight * np.sin(h * phase)

    noise = np.random.normal(0, 0.03, len(t))
    signal = harmonics + noise
    signal = signal / (np.max(np.abs(signal)) + 1e-6)
    wavfile.write(filepath, sr, (signal * 32767.0).astype(np.int16))


def generate_synthetic_clone(filepath: str, duration: float = 2.5, sr: int = 16000):
    t = np.linspace(0, duration, int(sr * duration), endpoint=False)
    f0 = 125.0
    phase = 2 * np.pi * f0 * t

    harmonics = np.zeros_like(t)
    for h in range(1, 30):
        harmonics += (1.0 / np.sqrt(h)) * np.sin(h * phase + np.random.uniform(-0.3, 0.3))

    vocoder_noise = np.random.uniform(-0.1, 0.1, len(t))
    signal = harmonics + vocoder_noise

    sos = butter(12, 6800.0, 'lowpass', fs=sr, output='sos')
    filtered = sosfilt(sos, signal)
    filtered = filtered / (np.max(np.abs(filtered)) + 1e-6)
    wavfile.write(filepath, sr, (filtered * 32767.0).astype(np.int16))


def generate_video_frames(output_dir: str, is_deepfake: bool = False, num_frames: int = 60):
    os.makedirs(output_dir, exist_ok=True)
    w, h = 256, 256

    for i in range(num_frames):
        img = np.ones((h, w, 3), dtype=np.uint8) * 30
        cv2.ellipse(img, (w//2, h//2), (60, 75), 0, 0, 360, (180, 150, 130), -1)

        if not is_deepfake:
            noise = np.random.normal(0, 5, img.shape).astype(np.int16)
            img = np.clip(img.astype(np.int16) + noise, 0, 255).astype(np.uint8)
            is_blink = (15 <= i <= 20) or (45 <= i <= 50)
            eye_h = 2 if is_blink else 10
            cv2.ellipse(img, (w//2 - 25, h//2 - 15), (12, eye_h), 0, 0, 360, (20, 20, 20), -1)
            cv2.ellipse(img, (w//2 + 25, h//2 - 15), (12, eye_h), 0, 0, 360, (20, 20, 20), -1)
            m_h = int(6 + 8 * np.abs(np.sin(i * 0.3)))
            cv2.ellipse(img, (w//2, h//2 + 35), (20, m_h), 0, 0, 360, (40, 20, 80), -1)
        else:
            cv2.ellipse(img, (w//2 - 25, h//2 - 15), (12, 10), 0, 0, 360, (20, 20, 20), -1)
            cv2.ellipse(img, (w//2 + 25, h//2 - 15), (12, 10), 0, 0, 360, (20, 20, 20), -1)
            cv2.ellipse(img, (w//2, h//2 + 35), (20, 6), 0, 0, 360, (40, 20, 80), -1)
            cv2.ellipse(img, (w//2, h//2), (61, 76), 0, 0, 360, (255, 255, 255), 2)

        cv2.imwrite(os.path.join(output_dir, f"frame_{i:03d}.png"), img)


def generate_extension_icons():
    icons_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "extension", "icons")
    os.makedirs(icons_dir, exist_ok=True)
    for sz in [16, 48, 128]:
        img = np.zeros((sz, sz, 3), dtype=np.uint8)
        img[:, :] = (11, 17, 32)
        cv2.circle(img, (sz//2, sz//2), sz//2 - 2, (0, 242, 254), 2)
        cv2.imwrite(os.path.join(icons_dir, f"icon{sz}.png"), img)


def main():
    root = os.path.dirname(os.path.abspath(__file__))
    generate_pristine_voice(os.path.join(root, "pristine_voice.wav"))
    generate_synthetic_clone(os.path.join(root, "synthetic_clone_voice.wav"))
    generate_video_frames(os.path.join(root, "pristine_frames"), is_deepfake=False)
    generate_video_frames(os.path.join(root, "synthetic_frames"), is_deepfake=True)
    generate_extension_icons()
    print("[OK] Generated base fixtures and icons.")


if __name__ == "__main__":
    main()
