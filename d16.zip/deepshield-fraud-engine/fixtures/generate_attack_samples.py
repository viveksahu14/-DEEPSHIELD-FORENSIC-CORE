import os
import numpy as np
import scipy.io.wavfile as wavfile
from scipy.signal import butter, sosfilt


def generate_ceo_voice_clone(filepath: str, duration: float = 3.5, sr: int = 16000):
    t = np.linspace(0, duration, int(sr * duration), endpoint=False)
    f0 = 125.0
    phase = 2 * np.pi * f0 * t

    harmonics = np.zeros_like(t)
    for h in range(1, 35):
        harmonics += (1.0 / np.sqrt(h)) * np.sin(h * phase + np.random.uniform(-0.4, 0.4))

    vocoder_noise = np.random.uniform(-0.12, 0.12, len(t))
    signal = harmonics + vocoder_noise

    sos = butter(12, 6800.0, 'lowpass', fs=sr, output='sos')
    filtered = sosfilt(sos, signal)
    filtered = filtered / (np.max(np.abs(filtered)) + 1e-6)
    wavfile.write(filepath, sr, (filtered * 32767.0).astype(np.int16))


def generate_authentic_cfo_voice(filepath: str, duration: float = 3.5, sr: int = 16000):
    t = np.linspace(0, duration, int(sr * duration), endpoint=False)
    f0 = 135.0 + 3.5 * np.sin(2 * np.pi * 4.8 * t)
    phase = 2 * np.pi * np.cumsum(f0) / sr

    harmonics = np.zeros_like(t)
    for h in range(1, 40):
        freq = h * 135.0
        weight = 1.0 / (1.0 + ((freq - 500)/150)**2) + 0.65 / (1.0 + ((freq - 1500)/200)**2) + 0.35 / (1.0 + ((freq - 2500)/300)**2)
        weight += 0.08 / (1.0 + (freq / 5500.0)**2)
        harmonics += weight * np.sin(h * phase)

    air_breath = np.random.normal(0, 0.035, len(t))
    signal = harmonics + air_breath
    signal = signal / (np.max(np.abs(signal)) + 1e-6)
    wavfile.write(filepath, sr, (signal * 32767.0).astype(np.int16))


def generate_noisy_masked_spoof(filepath: str, duration: float = 3.5, sr: int = 16000):
    t = np.linspace(0, duration, int(sr * duration), endpoint=False)
    f0 = 140.0
    phase = 2 * np.pi * f0 * t

    synthetic_voice = np.zeros_like(t)
    for h in range(1, 30):
        synthetic_voice += (1.0 / h) * np.sin(h * phase)

    sos = butter(10, 6500.0, 'lowpass', fs=sr, output='sos')
    filtered_voice = sosfilt(sos, synthetic_voice)

    ambient_noise = np.random.normal(0, 0.15, len(t))
    combined = (0.7 * filtered_voice) + (0.3 * ambient_noise)
    combined = combined / (np.max(np.abs(combined)) + 1e-6)
    wavfile.write(filepath, sr, (combined * 32767.0).astype(np.int16))


def generate_all_samples():
    samples_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "samples")
    os.makedirs(samples_dir, exist_ok=True)

    generate_ceo_voice_clone(os.path.join(samples_dir, "ceo_voice_clone_urgent_wire.wav"))
    generate_authentic_cfo_voice(os.path.join(samples_dir, "authentic_cfo_confirmation.wav"))
    generate_noisy_masked_spoof(os.path.join(samples_dir, "noisy_ambient_voice_spoof.wav"))
    print("[OK] Generated realistic attack samples.")


if __name__ == "__main__":
    generate_all_samples()
