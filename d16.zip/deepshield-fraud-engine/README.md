# DeepShield - Deepfake Voice & Media Detection Engine for Financial Fraud

Real-time microservice built to detect AI voice cloning, deepfake video streams, and audio-video desynchronization during high-value wire transfers and biometric identity checks.

Developed for the Cyber Security Hackathon challenge on financial fraud prevention.

---

## Key Capabilities

1. **Acoustic Spectral Forensics (`backend/analyzer/spectral_audio.py`)**
   - Flags neural vocoder frequency brick-wall cutoffs (>7 kHz) characteristic of HiFi-GAN and Tacotron models.
   - Computes Wiener spectral flatness (entropy) to isolate artificial floor noise from natural harmonic vocal tracts.
   - Calculates phase derivative continuity to expose diffusion phase flux jitter.
   - Computes cepstral peak prominence (CPP) for monotone pitch invariance.

2. **Facial Micro-Expressions & Seam Analysis (`backend/analyzer/video_microexpression.py`)**
   - Tracks Eye Aspect Ratio (EAR) over time to flag static eye syndrome (<4 BPM) and synthetic flutter (>40 BPM).
   - Computes Laplacian boundary gradient ratios along face perimeters to detect Poisson blending and alpha-mask seams.
   - Measures spatial cheek patch variance to flag diffusion/GAN over-smoothing.

3. **Lip-Sync Phoneme-Viseme Alignment (`backend/analyzer/lipsync_discrepancy.py`)**
   - Matches Short-Time Energy envelopes against Mouth Aspect Ratio (MAR) kinematics.
   - Calculates normalized cross-correlation across temporal lags to catch out-of-order dubbing (>120ms lag).

4. **Banking Gatekeeper & Tamper-Evident Ledger (`backend/middleware/`)**
   - Financial transactions evaluated in **INR (₹ Rupees)** with editable sender and receiver details.
   - Policy-driven gatekeeper: auto-approves low risk (<30), triggers Step-Up MFA on medium risk (30-65), and freezes high/critical risk (>=65).
   - Generates SHA-256 hash-chained audit records for regulatory compliance.

5. **Interactive HUD Dashboard & Browser Extension (`frontend/`, `extension/`)**
   - Dark neon cyber dashboard with radial risk gauge, live canvas spectrogram, facial landmark mesh, and wire transfer simulator.
   - Manifest V3 browser extension for in-page transaction inspection.

---

## Project Structure

```
deepshield-fraud-engine/
├── start.bat                       # 1-Click Launch on Windows (with auto-port resolution)
├── run_tests.bat                   # 1-Click Test Suite Runner
├── run_server.py                   # Python server launcher
├── run_tests.py                    # Standalone test runner (13 automated tests)
├── test_samples.py                 # CLI evaluator for real-world attack scenarios
├── README.md                       # Project documentation
├── ARCHITECTURE.md                 # Signal processing & algorithm specifications
├── requirements.txt                # Python dependencies
│
├── backend/
│   ├── app.py                      # FastAPI app entry & CORS configuration
│   ├── config.py                   # INR policy limits & detection thresholds
│   ├── analyzer/
│   │   ├── engine.py               # Multimodal risk aggregator
│   │   ├── spectral_audio.py       # Audio vocoder & phase analyzer
│   │   ├── video_microexpression.py# Video blink & boundary seam analyzer
│   │   └── lipsync_discrepancy.py  # Audio-visual correlation engine
│   ├── middleware/
│   │   ├── banking_interceptor.py  # Wire transfer gatekeeper
│   │   └── audit_logger.py         # SHA-256 chained audit ledger
│   ├── api/
│   │   ├── routes_detection.py     # Media analysis & WebSocket stream routes
│   │   ├── routes_banking.py       # Wire transfer & audit routes
│   │   └── schemas.py              # Pydantic data schemas
│   └── utils/
│       ├── audio_utils.py          # Audio STFT & energy extractors
│       └── video_utils.py          # Face ROI, EAR/MAR extractors
│
├── frontend/                       # Interactive Fintech HUD Dashboard
│   ├── index.html                  # Dashboard HTML with editable INR form
│   ├── css/styles.css              # Cyberpunk dark styling
│   └── js/                         # WebSockets, audio visualizer & banking controller
│
├── extension/                      # Chrome Manifest V3 Browser Extension
│   ├── manifest.json
│   ├── popup/
│   ├── background/
│   └── content/
│
├── samples/                        # Real-world Attack Vector Samples
│   ├── ceo_voice_clone_urgent_wire.wav
│   ├── authentic_cfo_confirmation.wav
│   └── noisy_ambient_voice_spoof.wav
│
├── fixtures/                       # Test generators & synthetic frame batches
└── tests/                          # Automated unit and integration tests
```

---

## Quick Start

### 1. Installation
```bash
pip install -r requirements.txt
```

### 2. Run Automated Verification Tests
```bash
python run_tests.py
```

### 3. Start the Server & Open Dashboard
```bash
python run_server.py
```
- **Dashboard**: `http://127.0.0.1:8000` (or `http://127.0.0.1:8001` if port 8000 is busy)
- **API Swagger Docs**: `http://127.0.0.1:8000/docs`
