import os
import sys

root_dir = os.path.dirname(os.path.abspath(__file__))
if root_dir not in sys.path:
    sys.path.insert(0, root_dir)

from backend.analyzer.engine import master_engine
from backend.middleware.banking_interceptor import banking_gatekeeper, TransferAuthorizationRequest
from backend.utils.audio_utils import load_audio_bytes


def evaluate_sample_scenarios():
    print("=" * 80)
    print("[DEEPSHIELD] FORENSIC EVALUATION OF REAL-WORLD FINANCIAL FRAUD ATTACK VECTORS")
    print("=" * 80)

    samples = [
        {
            "name": "Scenario 1: CEO AI Voice Clone (Rs 50,00,000 Urgent Wire Transfer)",
            "file": os.path.join(root_dir, "samples", "ceo_voice_clone_urgent_wire.wav"),
            "account_from": "HDFC-CORP-TREASURY-098",
            "account_to": "OFFSHORE-PANAMA-88219",
            "amount_usd": 5000000.0,
            "auth_type": "CEO_EXECUTIVE_VOICE_CALL"
        },
        {
            "name": "Scenario 2: Authentic CFO Confirmation (Rs 1,50,000 Vendor Invoice)",
            "file": os.path.join(root_dir, "samples", "authentic_cfo_confirmation.wav"),
            "account_from": "HDFC-CORP-TREASURY-098",
            "account_to": "ICICI-VERIFIED-SUPPLIER-114",
            "amount_usd": 150000.0,
            "auth_type": "CFO_EXECUTIVE_VOICE_CALL"
        },
        {
            "name": "Scenario 3: Noisy Ambient Masked Voice Clone (Rs 12,00,000 Payment)",
            "file": os.path.join(root_dir, "samples", "noisy_ambient_voice_spoof.wav"),
            "account_from": "HDFC-CORP-TREASURY-098",
            "account_to": "OFFSHORE-CYPRUS-55012",
            "amount_usd": 1200000.0,
            "auth_type": "VOICE_PHONE_CALL"
        }
    ]

    for s in samples:
        print(f"\n>> Testing: {s['name']}")
        print(f"  Target File: {os.path.basename(s['file'])}")
        print(f"  Amount: Rs {s['amount_usd']:,.2f} | From: {s['account_from']} -> To: {s['account_to']}")
        
        if not os.path.exists(s["file"]):
            print(f"  [ERROR] File missing: {s['file']}")
            continue

        with open(s["file"], "rb") as f:
            audio_arr, sr = load_audio_bytes(f.read())

        risk_report = master_engine.analyze_media(audio_array=audio_arr, audio_sr=sr)
        
        req = TransferAuthorizationRequest(
            account_from=s["account_from"],
            account_to=s["account_to"],
            amount_usd=s["amount_usd"],
            authorization_type=s["auth_type"]
        )
        auth_decision = banking_gatekeeper.evaluate_transfer(req, risk_report)

        print(f"  [THREAT LEVEL]: {risk_report.risk_level} (Risk Score: {risk_report.overall_risk_score}/100, Confidence: {risk_report.confidence*100:.0f}%)")
        print(f"  [GATEKEEPER DECISION]: {auth_decision.decision}")
        print(f"  [STATUS]: {auth_decision.decision}")
        if risk_report.aggregated_artifacts:
            print(f"  [FORENSIC FLAGS]:")
            for art in risk_report.aggregated_artifacts:
                print(f"    * {art}")
        else:
            print(f"  [FORENSIC FLAGS]: None (Authentic biological acoustic signatures)")
        print(f"  [AUDIT LEDGER ID]: {auth_decision.audit_entry_id}")
        print("-" * 80)


if __name__ == "__main__":
    evaluate_sample_scenarios()
