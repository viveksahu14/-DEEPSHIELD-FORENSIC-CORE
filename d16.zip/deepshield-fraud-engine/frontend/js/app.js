const $ = id => document.getElementById(id);

document.addEventListener('DOMContentLoaded', () => {
  const scenarioBtns = document.querySelectorAll('.scenario-btn');
  const audioInput = $('customAudioFile');
  const videoInput = $('customVideoFile');
  const clearBtn = $('clearInputsBtn');
  const resetFormBtn = $('resetFormBtn');
  const streamToggle = $('toggleWebcamBtn');
  const videoElem = $('liveVideo');

  let activeMediaStream = null;
  let frameTimer = null;

  // 1. Scenario Button Handlers
  scenarioBtns.forEach(btn => {
    btn.addEventListener('click', async () => {
      scenarioBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      if (audioInput) audioInput.value = '';
      if (videoInput) videoInput.value = '';
      const scenarioKey = btn.dataset.scenario;
      await triggerSimulation(scenarioKey);
    });
  });

  // 2. Custom Audio / Video File Upload Handlers (Instant inspection strictly based on uploaded file)
  if (audioInput) {
    audioInput.addEventListener('change', async () => {
      if (audioInput.files && audioInput.files.length > 0) {
        scenarioBtns.forEach(b => b.classList.remove('active'));
        const currentVideo = (videoInput && videoInput.files && videoInput.files.length > 0) ? videoInput.files[0] : null;
        await uploadAndAnalyzeMedia(audioInput.files[0], currentVideo);
      }
    });
  }

  if (videoInput) {
    videoInput.addEventListener('change', async () => {
      if (videoInput.files && videoInput.files.length > 0) {
        scenarioBtns.forEach(b => b.classList.remove('active'));
        const currentAudio = (audioInput && audioInput.files && audioInput.files.length > 0) ? audioInput.files[0] : null;
        await uploadAndAnalyzeMedia(currentAudio, videoInput.files[0]);
      }
    });
  }

  async function uploadAndAnalyzeMedia(audioFile, videoFile) {
    const form = new FormData();
    if (audioFile) form.append('audio_file', audioFile);
    if (videoFile) form.append('video_file', videoFile);

    const nameStr = [audioFile ? audioFile.name : null, videoFile ? videoFile.name : null].filter(Boolean).join(' + ');
    if ($('verdictHeadline')) $('verdictHeadline').textContent = 'Analyzing Uploaded File...';
    if ($('forensicSummary')) $('forensicSummary').textContent = `Inspecting ${nameStr}... running spectral STFT analysis and facial micro-expression forensics...`;

    try {
      const resp = await fetch('/api/v1/detect/multimodal', {
        method: 'POST',
        body: form
      });
      if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
      const report = await resp.json();
      applyForensicReport(report);
    } catch (err) {
      console.error('File inspection error:', err);
      alert(`File analysis error: ${err.message}`);
    }
  }

  async function triggerSimulation(scenario) {
    try {
      if ($('verdictHeadline')) $('verdictHeadline').textContent = 'Analyzing Forensic Stream...';
      if ($('forensicSummary')) $('forensicSummary').textContent = 'Decomposing acoustic spectrum, blink kinematics, and viseme alignment...';

      const resp = await fetch('/api/v1/banking/simulate-scenario', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          scenario: scenario,
          account_from: $('accFrom') ? $('accFrom').value : 'HDFC-CORP-98812 (Treasury Desk)',
          account_to: $('accTo') ? $('accTo').value : 'ICICI-BENEFICIARY-44102 (Offshore)',
          transfer_amount_usd: $('txAmount') ? parseFloat($('txAmount').value) : 2500000.0
        })
      });

      if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
      const data = await resp.json();
      
      applyForensicReport(data.risk_report);
      if (window.bankingController) {
        window.bankingController.showAuthorizationResult(data.authorization_decision);
        window.bankingController.fetchAuditLogs();
      }
    } catch (err) {
      console.error('Simulation error:', err);
    }
  }

  // 3. Clear Inputs / Reset Functionality
  function resetAllInputs() {
    if (audioInput) audioInput.value = '';
    if (videoInput) videoInput.value = '';
    scenarioBtns.forEach(b => b.classList.remove('active'));

    // Reset Top HUD to Standby
    $('overallRiskScore').textContent = '0.0';
    $('riskLevelBadge').textContent = 'SYSTEM IDLE';
    $('riskLevelBadge').className = 'verdict-tag';
    $('actionBadge').textContent = 'STANDBY';
    $('actionBadge').style.color = 'var(--text-dim)';
    $('verdictHeadline').textContent = 'Awaiting Media Input';
    $('forensicSummary').textContent = 'Upload an audio/video file or select a biometric sample to evaluate synthetic risk.';

    const ring = $('gaugeRing');
    ring.style.borderColor = 'var(--border-color)';
    ring.style.boxShadow = 'none';

    // Reset Metric Pills
    $('audioSubScore').textContent = 'Score: --';
    $('videoSubScore').textContent = 'Score: --';
    $('lipsyncSubScore').textContent = 'Score: --';
    $('blinkRateDisplay').textContent = '-- BPM';
    $('boundarySeamDisplay').textContent = '--';
    $('skinAnomalyDisplay').textContent = '--';
    $('syncLagDisplay').textContent = '-- ms';
    $('visemeCorrDisplay').textContent = '--';

    // Reset Visualizer Canvases
    if (window.forensicVisualizer) {
      window.forensicVisualizer.initCanvases();
    }

    // Hide Intercept Banner
    const banner = $('interceptBanner');
    if (banner) banner.style.display = 'none';

    // Shutdown live stream if running
    shutdownStream();
  }

  if (clearBtn) clearBtn.addEventListener('click', resetAllInputs);
  if (resetFormBtn) resetFormBtn.addEventListener('click', resetAllInputs);

  // 4. Bind UI elements to the exact fetched data
  function applyForensicReport(rep) {
    if (!rep) return;

    const score = rep.overall_risk_score;
    $('overallRiskScore').textContent = score.toFixed(1);
    $('riskLevelBadge').textContent = rep.risk_level;
    $('actionBadge').textContent = rep.recommended_action === 'BLOCK' ? '🚨 BLOCK' : (rep.recommended_action === 'STEP_UP_AUTH' ? '⚠️ STEP-UP MFA' : '✅ ALLOW');
    $('forensicSummary').textContent = rep.forensic_summary;

    const ring = $('gaugeRing');
    const badge = $('riskLevelBadge');
    const action = $('actionBadge');
    const headline = $('verdictHeadline');

    if (rep.risk_level === 'CRITICAL' || rep.risk_level === 'HIGH') {
      ring.style.borderColor = 'var(--neon-red)';
      ring.style.boxShadow = '0 0 24px rgba(255, 23, 68, 0.5)';
      badge.className = 'verdict-tag badge-red';
      action.style.color = 'var(--neon-red)';
      headline.textContent = '🚨 CRITICAL DEEPFAKE THREAT DETECTED';
    } else if (rep.risk_level === 'MEDIUM') {
      ring.style.borderColor = 'var(--neon-amber)';
      ring.style.boxShadow = '0 0 20px rgba(255, 171, 0, 0.4)';
      badge.className = 'verdict-tag badge-amber';
      action.style.color = 'var(--neon-amber)';
      headline.textContent = '⚠️ SUSPICIOUS SYNTHETIC INDICATORS';
    } else {
      ring.style.borderColor = 'var(--neon-green)';
      ring.style.boxShadow = '0 0 20px rgba(0, 230, 118, 0.4)';
      badge.className = 'verdict-tag badge-green';
      action.style.color = 'var(--neon-green)';
      headline.textContent = '✅ AUTHENTIC BIOMETRICS VERIFIED';
    }

    // Audio Graph & Metrics from Fetched Data
    if (rep.audio_report) {
      $('audioSubScore').textContent = `Score: ${rep.audio_report.risk_score.toFixed(1)}`;
      window.forensicVisualizer.renderSpectrogram(
        rep.audio_report.spectrogram_preview,
        rep.audio_report.high_frequency_cutoff_detected
      );
    } else {
      $('audioSubScore').textContent = 'Score: --';
      window.forensicVisualizer.drawEmptySpectrogram();
    }

    // Video Graph & Metrics from Fetched Data
    if (rep.video_report) {
      $('videoSubScore').textContent = `Score: ${rep.video_report.risk_score.toFixed(1)}`;
      $('blinkRateDisplay').textContent = `${rep.video_report.blink_rate_bpm} BPM`;
      $('boundarySeamDisplay').textContent = `${rep.video_report.boundary_seam_score}`;
      $('skinAnomalyDisplay').textContent = `${rep.video_report.skin_texture_anomaly}`;

      window.forensicVisualizer.renderBlinkTimeline(
        rep.video_report.ear_timeline,
        rep.video_report.mar_timeline,
        rep.video_report.blink_anomaly_detected
      );
    } else {
      $('videoSubScore').textContent = 'Score: --';
      $('blinkRateDisplay').textContent = '-- BPM';
      $('boundarySeamDisplay').textContent = '--';
      $('skinAnomalyDisplay').textContent = '--';
      window.forensicVisualizer.drawEmptyVideoMesh();
    }

    // Lip-Sync Graph & Metrics from Fetched Data
    if (rep.lipsync_report) {
      $('lipsyncSubScore').textContent = `Score: ${rep.lipsync_report.risk_score.toFixed(1)}`;
      $('syncLagDisplay').textContent = `${rep.lipsync_report.sync_lag_ms} ms`;
      $('visemeCorrDisplay').textContent = `${rep.lipsync_report.viseme_correlation_score}`;

      window.forensicVisualizer.renderLipSyncCurves(
        rep.lipsync_report.audio_energy_timeline,
        rep.lipsync_report.mar_motion_timeline,
        rep.lipsync_report.is_desynchronized,
        rep.lipsync_report.sync_lag_ms
      );
    } else {
      $('lipsyncSubScore').textContent = 'Score: --';
      $('syncLagDisplay').textContent = '-- ms';
      $('visemeCorrDisplay').textContent = '--';
      window.forensicVisualizer.drawEmptyLipSync();
    }
  }

  window.applyForensicReport = applyForensicReport;

  // Live Camera
  if (streamToggle) {
    streamToggle.addEventListener('click', async () => {
      if (activeMediaStream) shutdownStream();
      else await initLiveCamera();
    });
  }

  async function initLiveCamera() {
    try {
      activeMediaStream = await navigator.mediaDevices.getUserMedia({ video: true, audio: false });
      videoElem.srcObject = activeMediaStream;
      videoElem.style.display = 'block';
      streamToggle.textContent = 'Stop Live Stream';
      streamToggle.style.background = 'var(--neon-red)';

      const cvs = document.createElement('canvas');
      const ctx = cvs.getContext('2d');
      cvs.width = 320;
      cvs.height = 240;

      frameTimer = setInterval(async () => {
        ctx.drawImage(videoElem, 0, 0, cvs.width, cvs.height);
        const b64 = cvs.toDataURL('image/jpeg', 0.6);
        try {
          const resp = await fetch('/api/v1/detect/stream-frame', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ frame_base64: b64 })
          });
          if (resp.ok) {
            const data = await resp.json();
            $('overallRiskScore').textContent = data.current_risk_score.toFixed(1);
            $('blinkRateDisplay').textContent = `EAR: ${data.ear}`;
          }
        } catch {}
      }, 150);
    } catch (err) {
      alert(`Camera access error: ${err.message}`);
      shutdownStream();
    }
  }

  function shutdownStream() {
    if (activeMediaStream) {
      activeMediaStream.getTracks().forEach(t => t.stop());
      activeMediaStream = null;
    }
    if (frameTimer) {
      clearInterval(frameTimer);
      frameTimer = null;
    }
    videoElem.style.display = 'none';
    streamToggle.textContent = 'Start Live Stream';
    streamToggle.style.background = 'linear-gradient(135deg, #00f2fe 0%, #4facfe 100%)';
  }
});
