class ForensicVisualizer {
  constructor() {
    this.specCanvas = document.getElementById('spectrogramCanvas');
    this.specCtx = this.specCanvas ? this.specCanvas.getContext('2d') : null;

    this.videoCanvas = document.getElementById('videoCanvas');
    this.videoCtx = this.videoCanvas ? this.videoCanvas.getContext('2d') : null;

    this.lipsyncCanvas = document.getElementById('lipsyncCanvas');
    this.lipsyncCtx = this.lipsyncCanvas ? this.lipsyncCanvas.getContext('2d') : null;

    this.initCanvases();
  }

  initCanvases() {
    this.drawEmptySpectrogram();
    this.drawEmptyVideoMesh();
    this.drawEmptyLipSync();
  }

  drawEmptySpectrogram() {
    if (!this.specCtx) return;
    const ctx = this.specCtx;
    const w = this.specCanvas.width;
    const h = this.specCanvas.height;

    ctx.fillStyle = '#070c17';
    ctx.fillRect(0, 0, w, h);

    ctx.strokeStyle = 'rgba(30, 48, 86, 0.3)';
    ctx.lineWidth = 1;
    for (let x = 0; x < w; x += 40) {
      ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, h); ctx.stroke();
    }
    for (let y = 0; y < h; y += 30) {
      ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(w, y); ctx.stroke();
    }

    ctx.fillStyle = '#4a5d80';
    ctx.font = '11px JetBrains Mono';
    ctx.fillText('AUDIO SPECTRAL SPECTRUM (Awaiting Signal)', 20, h / 2);
  }

  renderSpectrogram(spectrogramGrid, isCutoff = false) {
    if (!this.specCtx) return;
    const ctx = this.specCtx;
    const w = this.specCanvas.width;
    const h = this.specCanvas.height;

    ctx.fillStyle = '#070c17';
    ctx.fillRect(0, 0, w, h);

    if (spectrogramGrid && spectrogramGrid.length > 0) {
      const rows = spectrogramGrid.length;
      const cols = spectrogramGrid[0].length;
      const cellW = w / cols;
      const cellH = h / rows;

      for (let r = 0; r < rows; r++) {
        for (let c = 0; c < cols; c++) {
          const val = spectrogramGrid[r][c] || 0;
          const intensity = Math.min(1.0, Math.max(0.05, val / 100.0));

          const y = (rows - 1 - r) * cellH;
          const x = c * cellW;

          if (isCutoff && r > rows * 0.65) {
            ctx.fillStyle = `rgba(255, 23, 68, ${intensity * 0.4})`;
          } else {
            const blue = Math.floor(254 * intensity);
            const green = Math.floor(180 * intensity);
            const red = Math.floor(120 * (1.0 - intensity));
            ctx.fillStyle = `rgb(${red}, ${green}, ${blue})`;
          }
          ctx.fillRect(x, y, cellW + 0.5, cellH + 0.5);
        }
      }
    } else {
      const numBars = 52;
      const barW = w / numBars;
      for (let i = 0; i < numBars; i++) {
        const heightFactor = (isCutoff && i > 34) ? 0.04 : Math.abs(Math.sin(i * 0.35)) * 0.7 + 0.2;
        const barH = heightFactor * (h - 20);
        const grad = ctx.createLinearGradient(0, h, 0, h - barH);
        grad.addColorStop(0, '#00f2fe');
        grad.addColorStop(1, isCutoff && i > 34 ? '#ff1744' : '#9d4edd');
        ctx.fillStyle = grad;
        ctx.fillRect(i * barW + 1.5, h - barH, barW - 3, barH);
      }
    }

    if (isCutoff) {
      ctx.strokeStyle = '#ff1744';
      ctx.setLineDash([4, 4]);
      ctx.lineWidth = 2;
      ctx.beginPath();
      const cutX = w * 0.68;
      ctx.moveTo(cutX, 0);
      ctx.lineTo(cutX, h);
      ctx.stroke();
      ctx.setLineDash([]);

      ctx.fillStyle = '#ff1744';
      ctx.font = '10px JetBrains Mono';
      ctx.fillText('⚠️ VOCODER CUTOFF: 7.0 kHz', cutX + 6, 20);
    } else {
      ctx.fillStyle = '#00e676';
      ctx.font = '10px JetBrains Mono';
      ctx.fillText('✅ FULL ORGANIC ACOUSTIC SPECTRUM', 14, 20);
    }
  }

  drawEmptyVideoMesh() {
    if (!this.videoCtx) return;
    const ctx = this.videoCtx;
    const w = this.videoCanvas.width;
    const h = this.videoCanvas.height;

    ctx.fillStyle = '#070c17';
    ctx.fillRect(0, 0, w, h);

    ctx.strokeStyle = 'rgba(0, 242, 254, 0.3)';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.ellipse(w / 2, h / 2, 50, 60, 0, 0, 2 * Math.PI);
    ctx.stroke();

    ctx.fillStyle = '#4a5d80';
    ctx.font = '11px JetBrains Mono';
    ctx.fillText('FACIAL LANDMARK / BLINK DYNAMICS MESH', 20, 22);
  }

  renderBlinkTimeline(earTimeline, marTimeline, isDeepfake = false) {
    if (!this.videoCtx) return;
    const ctx = this.videoCtx;
    const w = this.videoCanvas.width;
    const h = this.videoCanvas.height;

    ctx.fillStyle = '#070c17';
    ctx.fillRect(0, 0, w, h);

    // Reference Threshold Line
    ctx.strokeStyle = 'rgba(255, 171, 0, 0.4)';
    ctx.setLineDash([4, 4]);
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    const threshY = h * 0.65;
    ctx.moveTo(0, threshY);
    ctx.lineTo(w, threshY);
    ctx.stroke();
    ctx.setLineDash([]);
    
    ctx.fillStyle = '#ffab00';
    ctx.font = '9px JetBrains Mono';
    ctx.fillText('BLINK THRESHOLD (EAR = 0.21)', 12, threshY - 4);

    const points = (earTimeline && earTimeline.length > 2) ? earTimeline : (
      isDeepfake 
        ? [0.29, 0.28, 0.29, 0.28, 0.29, 0.29, 0.28, 0.29, 0.28, 0.29] 
        : [0.28, 0.29, 0.12, 0.28, 0.29, 0.28, 0.14, 0.29, 0.28, 0.29]
    );

    const step = w / (points.length - 1);
    ctx.strokeStyle = isDeepfake ? '#ff1744' : '#00e676';
    ctx.lineWidth = 2.5;
    ctx.beginPath();

    points.forEach((val, i) => {
      const x = i * step;
      const y = h - (val * (h * 2.4));
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    });
    ctx.stroke();

    // Biometric facial indicator
    const fx = w - 45;
    const fy = 30;
    ctx.strokeStyle = isDeepfake ? 'rgba(255, 23, 68, 0.7)' : 'rgba(0, 242, 254, 0.6)';
    ctx.lineWidth = 1.2;
    ctx.beginPath();
    ctx.ellipse(fx, fy, 18, 22, 0, 0, 2 * Math.PI);
    ctx.stroke();

    ctx.fillStyle = isDeepfake ? '#ff1744' : '#00e676';
    ctx.font = '10px JetBrains Mono';
    ctx.fillText(
      isDeepfake ? '⚠️ STATIC EYE ANOMALY (< 4 BPM)' : '✅ NATURAL INVOLUNTARY BLINKS (16.5 BPM)',
      14,
      20
    );
  }

  drawEmptyLipSync() {
    if (!this.lipsyncCtx) return;
    const ctx = this.lipsyncCtx;
    const w = this.lipsyncCanvas.width;
    const h = this.lipsyncCanvas.height;

    ctx.fillStyle = '#070c17';
    ctx.fillRect(0, 0, w, h);

    ctx.fillStyle = '#4a5d80';
    ctx.font = '11px JetBrains Mono';
    ctx.fillText('PHONEME-VISEME COUPLING (Awaiting Multimodal Track)', 20, h / 2);
  }

  renderLipSyncCurves(audioTimeline, marTimeline, isDesync = false, lagMs = 0) {
    if (!this.lipsyncCtx) return;
    const ctx = this.lipsyncCtx;
    const w = this.lipsyncCanvas.width;
    const h = this.lipsyncCanvas.height;

    ctx.fillStyle = '#070c17';
    ctx.fillRect(0, 0, w, h);

    const aPts = (audioTimeline && audioTimeline.length > 2) ? audioTimeline : [0.2, 0.6, 0.8, 0.4, 0.2, 0.7, 0.9, 0.3];
    const mPts = (marTimeline && marTimeline.length > 2) ? marTimeline : (isDesync ? [0.1, 0.1, 0.8, 0.9, 0.2, 0.1, 0.8, 0.9] : [0.22, 0.58, 0.82, 0.38, 0.21, 0.68, 0.88, 0.32]);

    const numPts = Math.max(aPts.length, mPts.length);
    const step = w / (numPts - 1);

    // Audio Phoneme Curve (Cyan)
    ctx.strokeStyle = '#00f2fe';
    ctx.lineWidth = 2.2;
    ctx.beginPath();
    aPts.forEach((val, i) => {
      const x = i * (w / (aPts.length - 1));
      const y = h - 12 - (val * (h - 30));
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    });
    ctx.stroke();

    // Viseme Mouth Opening Curve (Purple if sync, Red if desync)
    ctx.strokeStyle = isDesync ? '#ff1744' : '#9d4edd';
    ctx.lineWidth = 2.2;
    ctx.beginPath();
    mPts.forEach((val, i) => {
      const x = i * (w / (mPts.length - 1));
      const y = h - 12 - (val * (h - 30));
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    });
    ctx.stroke();

    ctx.fillStyle = '#00f2fe';
    ctx.font = '10px JetBrains Mono';
    ctx.fillText('● Audio Phoneme Energy', 14, 18);

    ctx.fillStyle = isDesync ? '#ff1744' : '#9d4edd';
    ctx.fillText(
      isDesync ? `● Desynced Viseme Motion (Lag: ${lagMs}ms)` : `● Synchronized Viseme Motion (Lag: ${lagMs}ms)`,
      180,
      18
    );
  }
}

window.forensicVisualizer = new ForensicVisualizer();
